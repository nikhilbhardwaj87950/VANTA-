/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ArrowUp, Calendar, Phone, ArrowLeftRight } from 'lucide-react';

import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { BrandHighlights } from './components/BrandHighlights';
import { FeaturedCollection } from './components/FeaturedCollection';
import { SignatureExperience } from './components/SignatureExperience';
import { BrandStory } from './components/BrandStory';
import { DetailGallery } from './components/DetailGallery';
import { Testimonials } from './components/Testimonials';
import { EnquirySection } from './components/EnquirySection';
import { Footer } from './components/Footer';

import { VehicleModal } from './components/VehicleModal';
import { LightboxModal } from './components/LightboxModal';
import { SearchModal } from './components/SearchModal';
import { ConsultationModal } from './components/ConsultationModal';
import { LegalModal } from './components/LegalModal';
import { CompareModal } from './components/CompareModal';

import { Vehicle, GalleryItem, GALLERY_ITEMS } from './data/vehicles';

export default function App() {
  // Modal states
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);
  const [selectedGalleryItem, setSelectedGalleryItem] = useState<GalleryItem | null>(null);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isConsultationOpen, setIsConsultationOpen] = useState(false);
  const [consultationVehicle, setConsultationVehicle] = useState<string>('');
  const [selectedEnquiryVehicle, setSelectedEnquiryVehicle] = useState<string>('');
  
  // Compare modal state
  const [isCompareOpen, setIsCompareOpen] = useState(false);
  const [compareVehicleAId, setCompareVehicleAId] = useState<string | undefined>(undefined);
  const [compareVehicleBId, setCompareVehicleBId] = useState<string | undefined>(undefined);

  const handleOpenCompare = (vehicleAId?: string, vehicleBId?: string) => {
    if (vehicleAId) setCompareVehicleAId(vehicleAId);
    if (vehicleBId) setCompareVehicleBId(vehicleBId);
    setIsCompareOpen(true);
  };
  
  // Legal modal
  const [legalModalState, setLegalModalState] = useState<{ isOpen: boolean; title: string; content: string }>({
    isOpen: false,
    title: '',
    content: ''
  });

  // Back to top floating button
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 600);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectForEnquiry = (vehicleName: string) => {
    setSelectedEnquiryVehicle(vehicleName);
    scrollToSection('contact');
  };

  const handleBookConsultation = (vehicleName: string) => {
    setConsultationVehicle(vehicleName);
    setIsConsultationOpen(true);
  };

  const handleGalleryNavigate = (direction: 'next' | 'prev') => {
    if (!selectedGalleryItem) return;
    const currentIndex = GALLERY_ITEMS.findIndex((item) => item.id === selectedGalleryItem.id);
    if (currentIndex === -1) return;

    if (direction === 'next') {
      const nextIndex = (currentIndex + 1) % GALLERY_ITEMS.length;
      setSelectedGalleryItem(GALLERY_ITEMS[nextIndex]);
    } else {
      const prevIndex = (currentIndex - 1 + GALLERY_ITEMS.length) % GALLERY_ITEMS.length;
      setSelectedGalleryItem(GALLERY_ITEMS[prevIndex]);
    }
  };

  const openLegalModal = (title: string, content: string) => {
    setLegalModalState({
      isOpen: true,
      title,
      content
    });
  };

  return (
    <div className="min-h-screen bg-[#111110] text-[#F5F2EC] flex flex-col font-sans selection:bg-[#C6A56B] selection:text-[#111110]">
      {/* 1. Header & Navigation */}
      <Navbar
        onOpenSearch={() => setIsSearchOpen(true)}
        onExploreClick={() => scrollToSection('collection')}
        onOpenCompare={() => handleOpenCompare()}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* 2. Hero Section */}
        <Hero
          onExploreClick={() => scrollToSection('collection')}
          onStoryClick={() => scrollToSection('story')}
        />

        {/* 3. Trust and Brand Highlights */}
        <BrandHighlights />

        {/* 4. Featured Collection */}
        <FeaturedCollection
          onSelectVehicle={(vehicle) => setSelectedVehicle(vehicle)}
          onOpenCompare={(id) => handleOpenCompare(id)}
        />

        {/* 5. Signature Experience Section */}
        <SignatureExperience
          onDiscoverExperience={() => setIsConsultationOpen(true)}
        />

        {/* 6. Brand Story & Craftsmanship Atelier */}
        <BrandStory />

        {/* 7. Automotive Detail Gallery */}
        <DetailGallery
          onOpenLightbox={(item) => setSelectedGalleryItem(item)}
        />

        {/* 8. Illustrative Client Testimonials */}
        <Testimonials />

        {/* 9. Contact & Bespoke Enquiry Section */}
        <EnquirySection
          selectedVehiclePreset={selectedEnquiryVehicle}
        />
      </main>

      {/* 10. Premium Footer */}
      <Footer
        onOpenLegal={openLegalModal}
      />

      {/* Interactive Overlays & Modals */}
      {/* Vehicle Overview Modal */}
      <VehicleModal
        vehicle={selectedVehicle}
        onClose={() => setSelectedVehicle(null)}
        onSelectForEnquiry={handleSelectForEnquiry}
        onBookConsultation={handleBookConsultation}
        onOpenCompare={(id) => handleOpenCompare(id)}
      />

      {/* Side-by-Side Vehicle Comparison Modal */}
      <CompareModal
        isOpen={isCompareOpen}
        onClose={() => setIsCompareOpen(false)}
        initialVehicleAId={compareVehicleAId}
        initialVehicleBId={compareVehicleBId}
        onSelectForEnquiry={handleSelectForEnquiry}
        onBookConsultation={handleBookConsultation}
        onViewDetails={(vehicle) => {
          setIsCompareOpen(false);
          setSelectedVehicle(vehicle);
        }}
      />

      {/* Gallery Lightbox Modal */}
      <LightboxModal
        item={selectedGalleryItem}
        items={GALLERY_ITEMS}
        onClose={() => setSelectedGalleryItem(null)}
        onNavigate={handleGalleryNavigate}
      />

      {/* Quick Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectVehicle={(vehicle) => setSelectedVehicle(vehicle)}
      />

      {/* Consultation & VIP Test Drive Scheduler */}
      <ConsultationModal
        isOpen={isConsultationOpen}
        defaultVehicle={consultationVehicle}
        onClose={() => setIsConsultationOpen(false)}
      />

      {/* Legal & Terms Modal */}
      <LegalModal
        isOpen={legalModalState.isOpen}
        title={legalModalState.title}
        content={legalModalState.content}
        onClose={() => setLegalModalState((prev) => ({ ...prev, isOpen: false }))}
      />

      {/* Floating Action Buttons: Compare, VIP Concierge & Back to Top */}
      <div className="fixed bottom-6 right-6 z-30 flex flex-col items-end gap-3">
        <button
          onClick={() => handleOpenCompare()}
          className="group flex items-center gap-2 px-3.5 py-2.5 bg-[#1B1A18]/90 hover:bg-[#22211F] text-[#F5F2EC] hover:text-[#C6A56B] border border-[#C6A56B]/30 hover:border-[#C6A56B] rounded-full shadow-xl backdrop-blur-md transition-all duration-300 cursor-pointer text-xs font-medium uppercase tracking-wider"
          title="Compare Vehicles Side-by-Side"
        >
          <ArrowLeftRight className="w-3.5 h-3.5 text-[#C6A56B]" />
          <span className="hidden sm:inline">Compare</span>
        </button>

        <button
          onClick={() => setIsConsultationOpen(true)}
          className="group flex items-center gap-2.5 px-4 py-3 bg-[#1B1A18]/90 hover:bg-[#C6A56B] text-[#C6A56B] hover:text-[#111110] border border-[#C6A56B]/40 hover:border-[#C6A56B] rounded-full shadow-2xl backdrop-blur-md transition-all duration-300 cursor-pointer text-xs font-semibold uppercase tracking-wider"
          title="Schedule Private Consultation"
        >
          <Calendar className="w-4 h-4" />
          <span className="hidden sm:inline">VIP Atelier Concierge</span>
        </button>

        {showScrollTop && (
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="p-3 bg-[#22211F]/90 text-[#F5F2EC] hover:text-[#C6A56B] border border-[#C6A56B]/30 hover:border-[#C6A56B] rounded-full shadow-xl backdrop-blur-md transition-all duration-300 cursor-pointer"
            aria-label="Scroll to top"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
}
