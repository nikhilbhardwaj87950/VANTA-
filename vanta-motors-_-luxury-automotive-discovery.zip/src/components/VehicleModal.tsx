import React, { useState } from 'react';
import { X, ArrowRight, Gauge, Zap, Compass, Check, Calendar, Phone, ArrowLeftRight } from 'lucide-react';
import { Vehicle } from '../data/vehicles';
import { SafeImage } from './SafeImage';

interface VehicleModalProps {
  vehicle: Vehicle | null;
  onClose: () => void;
  onSelectForEnquiry: (vehicleName: string) => void;
  onBookConsultation: (vehicleName: string) => void;
  onOpenCompare?: (vehicleId: string) => void;
}

export const VehicleModal: React.FC<VehicleModalProps> = ({
  vehicle,
  onClose,
  onSelectForEnquiry,
  onBookConsultation,
  onOpenCompare
}) => {
  if (!vehicle) return null;

  const [selectedColor, setSelectedColor] = useState(vehicle.colors[0]);
  const [activeImageIndex, setActiveImageIndex] = useState(0);

  const images = [vehicle.imageUrl, ...(vehicle.gallery || [])];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div
        className="relative w-full max-w-5xl bg-[#1B1A18] border border-[#C6A56B]/30 rounded-xl overflow-hidden shadow-2xl my-8 animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 text-[#A9A49A] hover:text-[#C6A56B] bg-[#111110]/80 rounded-full border border-[#C6A56B]/20 transition-all hover:scale-110"
          aria-label="Close vehicle overview"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-12 max-h-[85vh] overflow-y-auto">
          {/* Left Column: Visual Showcase & Color Picker */}
          <div className="lg:col-span-7 bg-[#141312] p-6 lg:p-8 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-[#C6A56B]/15">
            <div>
              {/* Category & Name */}
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[10px] tracking-[0.25em] uppercase text-[#C6A56B] font-semibold">
                  {vehicle.category}
                </span>
                <span className="text-[#A9A49A]/40">·</span>
                <span className="text-xs text-[#A9A49A]">Starting from {vehicle.startingPrice}</span>
              </div>
              <h2 className="font-serif text-2xl sm:text-3xl text-[#F5F2EC] mb-2">
                {vehicle.name}
              </h2>
              <p className="text-xs sm:text-sm text-[#A9A49A] italic mb-6">
                "{vehicle.tagline}"
              </p>

              {/* Main Image Showcase */}
              <div className="relative aspect-[16/10] rounded-lg overflow-hidden border border-[#C6A56B]/20 bg-[#111110] mb-4 shadow-inner">
                <SafeImage
                  src={images[activeImageIndex] || vehicle.imageUrl}
                  alt={`${vehicle.name} in ${selectedColor.name}`}
                  className="w-full h-full object-cover transition-all duration-500"
                  fallbackTitle={vehicle.name}
                  fallbackCategory={vehicle.category}
                />
                
                {/* Visual Color Overlay Indicator */}
                <div className="absolute bottom-3 left-3 bg-[#111110]/85 backdrop-blur-sm px-3 py-1.5 rounded-sm border border-[#C6A56B]/25 flex items-center gap-2 text-xs">
                  <span
                    className="w-3 h-3 rounded-full border border-white/20"
                    style={{ backgroundColor: selectedColor.hex }}
                  />
                  <span className="text-[11px] text-[#F5F2EC] tracking-wider uppercase font-medium">
                    {selectedColor.name} ({selectedColor.finish})
                  </span>
                </div>
              </div>

              {/* Gallery Thumbnails */}
              {images.length > 1 && (
                <div className="flex items-center gap-2 mb-6">
                  {images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveImageIndex(idx)}
                      className={`relative w-16 h-11 rounded overflow-hidden border transition-all ${
                        activeImageIndex === idx
                          ? 'border-[#C6A56B] ring-1 ring-[#C6A56B]'
                          : 'border-[#C6A56B]/20 opacity-60 hover:opacity-100'
                      }`}
                    >
                      <img src={img} alt="Thumbnail" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Bespoke Exterior Palette Switcher */}
            <div className="pt-4 border-t border-[#C6A56B]/15">
              <label className="text-[10px] uppercase tracking-[0.2em] font-semibold text-[#A9A49A] block mb-2.5">
                Select Bespoke Exterior Finish
              </label>
              <div className="flex flex-wrap items-center gap-3">
                {vehicle.colors.map((color) => (
                  <button
                    key={color.name}
                    onClick={() => setSelectedColor(color)}
                    className={`group relative flex items-center gap-2 px-3 py-1.5 rounded-sm border text-xs transition-all ${
                      selectedColor.name === color.name
                        ? 'border-[#C6A56B] bg-[#22211F] text-[#F5F2EC]'
                        : 'border-[#C6A56B]/20 bg-[#161514] text-[#A9A49A] hover:border-[#C6A56B]/40'
                    }`}
                  >
                    <span
                      className="w-3.5 h-3.5 rounded-full border border-white/30 shrink-0"
                      style={{ backgroundColor: color.hex }}
                    />
                    <span className="text-[11px] tracking-wide">{color.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Technical Specifications & Inquiries */}
          <div className="lg:col-span-5 p-6 lg:p-8 flex flex-col justify-between bg-[#1B1A18]">
            <div>
              <h3 className="text-xs uppercase tracking-[0.25em] font-semibold text-[#C6A56B] mb-4">
                Technical Highlights
              </h3>

              {/* 4-Stat Grid */}
              <div className="grid grid-cols-2 gap-3 mb-6">
                <div className="p-3 bg-[#22211F] border border-[#C6A56B]/15 rounded">
                  <div className="flex items-center gap-1.5 text-[#A9A49A] text-[10px] uppercase tracking-wider mb-1">
                    <Zap className="w-3.5 h-3.5 text-[#C6A56B]" /> Power Output
                  </div>
                  <div className="text-xl font-serif text-[#F5F2EC]">{vehicle.horsepower}</div>
                </div>

                <div className="p-3 bg-[#22211F] border border-[#C6A56B]/15 rounded">
                  <div className="flex items-center gap-1.5 text-[#A9A49A] text-[10px] uppercase tracking-wider mb-1">
                    <Gauge className="w-3.5 h-3.5 text-[#C6A56B]" /> 0–60 MPH
                  </div>
                  <div className="text-xl font-serif text-[#F5F2EC]">{vehicle.acceleration}</div>
                </div>

                <div className="p-3 bg-[#22211F] border border-[#C6A56B]/15 rounded">
                  <div className="flex items-center gap-1.5 text-[#A9A49A] text-[10px] uppercase tracking-wider mb-1">
                    <Compass className="w-3.5 h-3.5 text-[#C6A56B]" /> Max Velocity
                  </div>
                  <div className="text-xl font-serif text-[#F5F2EC]">{vehicle.topSpeed}</div>
                </div>

                <div className="p-3 bg-[#22211F] border border-[#C6A56B]/15 rounded">
                  <div className="flex items-center gap-1.5 text-[#A9A49A] text-[10px] uppercase tracking-wider mb-1">
                    Efficiency / Range
                  </div>
                  <div className="text-xs font-serif text-[#F5F2EC] pt-1">{vehicle.rangeOrEconomy}</div>
                </div>
              </div>

              {/* Narrative description */}
              <p className="text-xs sm:text-sm text-[#A9A49A] font-light leading-relaxed mb-6">
                {vehicle.description}
              </p>

              {/* Bespoke Features List */}
              <div className="mb-6">
                <h4 className="text-[10px] uppercase tracking-[0.2em] font-semibold text-[#A9A49A] mb-3">
                  Coachbuilt Amenities
                </h4>
                <div className="space-y-2">
                  {vehicle.features.map((feat, i) => (
                    <div key={i} className="flex items-start gap-2.5 text-xs text-[#F5F2EC]/90">
                      <Check className="w-3.5 h-3.5 text-[#C6A56B] shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Dimensions */}
              <div className="pt-4 border-t border-[#C6A56B]/15 text-[11px] text-[#A9A49A] space-y-1 mb-6">
                <p><strong className="text-[#F5F2EC] font-medium">Powertrain:</strong> {vehicle.powertrain}</p>
                <p><strong className="text-[#F5F2EC] font-medium">Transmission:</strong> {vehicle.transmission}</p>
                <p><strong className="text-[#F5F2EC] font-medium">Dimensions:</strong> {vehicle.dimensions.length} × {vehicle.dimensions.width} × {vehicle.dimensions.height}</p>
              </div>
            </div>

            {/* CTAs */}
            <div className="pt-4 border-t border-[#C6A56B]/20 flex flex-col sm:flex-row gap-2.5">
              <button
                onClick={() => {
                  onSelectForEnquiry(vehicle.name);
                  onClose();
                }}
                className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-[#111110] bg-[#C6A56B] hover:bg-[#d6b77e] transition-colors rounded-sm cursor-pointer"
              >
                <span>Inquire About Model</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => {
                  onBookConsultation(vehicle.name);
                  onClose();
                }}
                className="inline-flex items-center justify-center gap-2 px-3.5 py-3 text-xs font-medium uppercase tracking-[0.14em] text-[#F5F2EC] bg-[#22211F] hover:bg-[#2c2b28] border border-[#C6A56B]/30 transition-colors rounded-sm cursor-pointer"
              >
                <Calendar className="w-3.5 h-3.5 text-[#C6A56B]" />
                <span>Test Drive</span>
              </button>

              {onOpenCompare && (
                <button
                  onClick={() => {
                    onOpenCompare(vehicle.id);
                    onClose();
                  }}
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-3 text-xs font-medium uppercase tracking-[0.14em] text-[#C6A56B] bg-[#161514] hover:bg-[#22211F] border border-[#C6A56B]/30 hover:border-[#C6A56B] transition-colors rounded-sm cursor-pointer"
                  title="Compare with another model"
                >
                  <ArrowLeftRight className="w-3.5 h-3.5" />
                  <span>Compare</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
