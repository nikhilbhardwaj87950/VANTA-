import React from 'react';
import { Maximize2, Sparkles } from 'lucide-react';
import { GALLERY_ITEMS, GalleryItem } from '../data/vehicles';
import { SafeImage } from './SafeImage';

interface DetailGalleryProps {
  onOpenLightbox: (item: GalleryItem) => void;
}

export const DetailGallery: React.FC<DetailGalleryProps> = ({ onOpenLightbox }) => {
  return (
    <section id="gallery" className="py-24 md:py-32 bg-[#161514] border-t border-[#C6A56B]/20">
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center justify-center gap-3 mb-3">
            <span className="w-6 h-[1px] bg-[#C6A56B]" />
            <span className="text-[11px] font-semibold tracking-[0.28em] uppercase text-[#C6A56B]">
              THE ARCHIVE OF DETAILS
            </span>
            <span className="w-6 h-[1px] bg-[#C6A56B]" />
          </div>
          <h2 className="font-serif text-3xl sm:text-5xl text-[#F5F2EC] font-normal leading-tight">
            Sculpted in Every Dimension.
          </h2>
          <p className="text-sm sm:text-base text-[#A9A49A] mt-3 font-light">
            An intimate photographic study of coachbuilt proportion, tactile upholstery, and mechanical poetry.
          </p>
        </div>

        {/* Asymmetrical Editorial Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Item 1: Wide hero item (columns 1 to 7) */}
          <div
            onClick={() => onOpenLightbox(GALLERY_ITEMS[0])}
            className="md:col-span-7 group relative aspect-[16/10] rounded-xl overflow-hidden bg-[#1B1A18] border border-[#C6A56B]/20 cursor-pointer shadow-lg hover:border-[#C6A56B]/60 transition-all duration-500"
          >
            <SafeImage
              src={GALLERY_ITEMS[0].imageUrl}
              alt={GALLERY_ITEMS[0].title}
              className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-106"
              fallbackTitle={GALLERY_ITEMS[0].title}
              fallbackCategory={GALLERY_ITEMS[0].category}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#111110]/90 via-[#111110]/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />
            <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between">
              <div>
                <span className="text-[10px] tracking-[0.25em] uppercase font-semibold text-[#C6A56B]">
                  {GALLERY_ITEMS[0].category}
                </span>
                <h3 className="font-serif text-xl sm:text-2xl text-[#F5F2EC] mt-1">
                  {GALLERY_ITEMS[0].title}
                </h3>
              </div>
              <div className="p-2.5 rounded-full bg-[#111110]/80 text-[#C6A56B] border border-[#C6A56B]/30 opacity-0 group-hover:opacity-100 transition-all transform translate-y-2 group-hover:translate-y-0">
                <Maximize2 className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* Item 2: Tall item (columns 8 to 12) */}
          <div
            onClick={() => onOpenLightbox(GALLERY_ITEMS[1])}
            className="md:col-span-5 group relative aspect-[4/3] md:aspect-auto rounded-xl overflow-hidden bg-[#1B1A18] border border-[#C6A56B]/20 cursor-pointer shadow-lg hover:border-[#C6A56B]/60 transition-all duration-500"
          >
            <SafeImage
              src={GALLERY_ITEMS[1].imageUrl}
              alt={GALLERY_ITEMS[1].title}
              className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-106"
              fallbackTitle={GALLERY_ITEMS[1].title}
              fallbackCategory={GALLERY_ITEMS[1].category}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#111110]/90 via-[#111110]/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />
            <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between">
              <div>
                <span className="text-[10px] tracking-[0.25em] uppercase font-semibold text-[#C6A56B]">
                  {GALLERY_ITEMS[1].category}
                </span>
                <h3 className="font-serif text-xl sm:text-2xl text-[#F5F2EC] mt-1">
                  {GALLERY_ITEMS[1].title}
                </h3>
              </div>
              <div className="p-2.5 rounded-full bg-[#111110]/80 text-[#C6A56B] border border-[#C6A56B]/30 opacity-0 group-hover:opacity-100 transition-all transform translate-y-2 group-hover:translate-y-0">
                <Maximize2 className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* Item 3: (columns 1 to 4) */}
          <div
            onClick={() => onOpenLightbox(GALLERY_ITEMS[2])}
            className="md:col-span-4 group relative aspect-[4/3] rounded-xl overflow-hidden bg-[#1B1A18] border border-[#C6A56B]/20 cursor-pointer shadow-lg hover:border-[#C6A56B]/60 transition-all duration-500"
          >
            <SafeImage
              src={GALLERY_ITEMS[2].imageUrl}
              alt={GALLERY_ITEMS[2].title}
              className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-106"
              fallbackTitle={GALLERY_ITEMS[2].title}
              fallbackCategory={GALLERY_ITEMS[2].category}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#111110]/90 via-transparent to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />
            <div className="absolute bottom-5 left-5 right-5 flex items-end justify-between">
              <div>
                <span className="text-[10px] tracking-[0.25em] uppercase font-semibold text-[#C6A56B]">
                  {GALLERY_ITEMS[2].category}
                </span>
                <h3 className="font-serif text-lg text-[#F5F2EC] mt-1">
                  {GALLERY_ITEMS[2].title}
                </h3>
              </div>
              <div className="p-2 rounded-full bg-[#111110]/80 text-[#C6A56B] border border-[#C6A56B]/30 opacity-0 group-hover:opacity-100 transition-all">
                <Maximize2 className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>

          {/* Item 4: (columns 5 to 8) */}
          <div
            onClick={() => onOpenLightbox(GALLERY_ITEMS[3])}
            className="md:col-span-4 group relative aspect-[4/3] rounded-xl overflow-hidden bg-[#1B1A18] border border-[#C6A56B]/20 cursor-pointer shadow-lg hover:border-[#C6A56B]/60 transition-all duration-500"
          >
            <SafeImage
              src={GALLERY_ITEMS[3].imageUrl}
              alt={GALLERY_ITEMS[3].title}
              className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-106"
              fallbackTitle={GALLERY_ITEMS[3].title}
              fallbackCategory={GALLERY_ITEMS[3].category}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#111110]/90 via-transparent to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />
            <div className="absolute bottom-5 left-5 right-5 flex items-end justify-between">
              <div>
                <span className="text-[10px] tracking-[0.25em] uppercase font-semibold text-[#C6A56B]">
                  {GALLERY_ITEMS[3].category}
                </span>
                <h3 className="font-serif text-lg text-[#F5F2EC] mt-1">
                  {GALLERY_ITEMS[3].title}
                </h3>
              </div>
              <div className="p-2 rounded-full bg-[#111110]/80 text-[#C6A56B] border border-[#C6A56B]/30 opacity-0 group-hover:opacity-100 transition-all">
                <Maximize2 className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>

          {/* Item 5: (columns 9 to 12) */}
          <div
            onClick={() => onOpenLightbox(GALLERY_ITEMS[4])}
            className="md:col-span-4 group relative aspect-[4/3] rounded-xl overflow-hidden bg-[#1B1A18] border border-[#C6A56B]/20 cursor-pointer shadow-lg hover:border-[#C6A56B]/60 transition-all duration-500"
          >
            <SafeImage
              src={GALLERY_ITEMS[4].imageUrl}
              alt={GALLERY_ITEMS[4].title}
              className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-106"
              fallbackTitle={GALLERY_ITEMS[4].title}
              fallbackCategory={GALLERY_ITEMS[4].category}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#111110]/90 via-transparent to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />
            <div className="absolute bottom-5 left-5 right-5 flex items-end justify-between">
              <div>
                <span className="text-[10px] tracking-[0.25em] uppercase font-semibold text-[#C6A56B]">
                  {GALLERY_ITEMS[4].category}
                </span>
                <h3 className="font-serif text-lg text-[#F5F2EC] mt-1">
                  {GALLERY_ITEMS[4].title}
                </h3>
              </div>
              <div className="p-2 rounded-full bg-[#111110]/80 text-[#C6A56B] border border-[#C6A56B]/30 opacity-0 group-hover:opacity-100 transition-all">
                <Maximize2 className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>

          {/* Item 6: Full width span (12 columns) */}
          <div
            onClick={() => onOpenLightbox(GALLERY_ITEMS[5])}
            className="md:col-span-12 group relative aspect-[21/9] sm:aspect-[24/9] rounded-xl overflow-hidden bg-[#1B1A18] border border-[#C6A56B]/20 cursor-pointer shadow-lg hover:border-[#C6A56B]/60 transition-all duration-500"
          >
            <SafeImage
              src={GALLERY_ITEMS[5].imageUrl}
              alt={GALLERY_ITEMS[5].title}
              className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-104"
              fallbackTitle={GALLERY_ITEMS[5].title}
              fallbackCategory={GALLERY_ITEMS[5].category}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#111110]/90 via-[#111110]/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />
            <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between">
              <div>
                <span className="text-[10px] tracking-[0.25em] uppercase font-semibold text-[#C6A56B]">
                  {GALLERY_ITEMS[5].category}
                </span>
                <h3 className="font-serif text-xl sm:text-2xl text-[#F5F2EC] mt-1">
                  {GALLERY_ITEMS[5].title}
                </h3>
                <p className="text-xs text-[#A9A49A] mt-1 hidden sm:block font-light">
                  {GALLERY_ITEMS[5].subtitle}
                </p>
              </div>
              <div className="p-2.5 rounded-full bg-[#111110]/80 text-[#C6A56B] border border-[#C6A56B]/30 opacity-0 group-hover:opacity-100 transition-all">
                <Maximize2 className="w-4 h-4" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
