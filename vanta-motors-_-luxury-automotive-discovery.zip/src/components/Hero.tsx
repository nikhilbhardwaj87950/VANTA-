import React from 'react';
import { ArrowRight, ChevronDown } from 'lucide-react';
import { SafeImage } from './SafeImage';

interface HeroProps {
  onExploreClick: () => void;
  onStoryClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreClick, onStoryClick }) => {
  return (
    <section id="hero" className="relative min-h-screen flex items-center overflow-hidden bg-[#111110]">
      {/* Background Cinematic Visual with dark luxury architectural lighting */}
      <div className="absolute inset-0 z-0">
        <SafeImage
          src="https://images.unsplash.com/photo-1617814076367-b759c7d7e738?auto=format&fit=crop&w=2400&q=90"
          alt="Vanta Motors Flagship Hypercar in Architectural Pavilion"
          className="w-full h-full object-cover object-right lg:object-[80%_center] scale-105 transition-transform duration-1000 ease-out"
          fallbackTitle="VANTA MOTORS"
          fallbackCategory="Automotive Excellence"
        />
        {/* Cinematic dark gradients for pristine editorial legibility */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#111110] via-[#111110]/80 to-transparent w-full lg:w-3/4" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#111110] via-transparent to-[#111110]/50" />
        {/* Subtle warm gold ambient vignette */}
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-[#C6A56B]/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Hero Content Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-10 py-32 sm:py-40 w-full">
        <div className="max-w-2xl lg:max-w-xl">
          {/* Eyebrow Label with Decorative Gold Line */}
          <div className="inline-flex items-center gap-3 mb-6">
            <span className="w-8 h-[1px] bg-[#C6A56B]" />
            <span className="text-[11px] sm:text-xs font-semibold tracking-[0.3em] uppercase text-[#C6A56B]">
              THE ART OF AUTOMOTIVE EXCELLENCE
            </span>
          </div>

          {/* Main Headline */}
          <h1 className="font-serif text-4xl sm:text-6xl lg:text-7xl font-normal tracking-tight text-[#F5F2EC] leading-[1.08] mb-6">
            Drive Beyond <br />
            <span className="italic font-light text-[#F5F2EC]/90">The Ordinary.</span>
          </h1>

          {/* Supporting Text */}
          <p className="text-base sm:text-lg text-[#A9A49A] font-light leading-relaxed mb-10 max-w-lg">
            Discover exceptional automobiles where timeless design, precision engineering, and unforgettable performance come together.
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
            <button
              onClick={onExploreClick}
              className="inline-flex items-center justify-center gap-3 px-8 py-4 text-xs font-semibold uppercase tracking-[0.22em] text-[#111110] bg-[#C6A56B] hover:bg-[#d6b77e] transition-all duration-300 shadow-xl shadow-black/40 rounded-sm cursor-pointer group"
            >
              <span>EXPLORE COLLECTION</span>
              <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
            </button>

            <button
              onClick={onStoryClick}
              className="inline-flex items-center justify-center px-8 py-4 text-xs font-medium uppercase tracking-[0.22em] text-[#F5F2EC] bg-[#1B1A18]/60 hover:bg-[#22211F] border border-[#C6A56B]/30 hover:border-[#C6A56B] transition-all duration-300 rounded-sm cursor-pointer backdrop-blur-sm"
            >
              DISCOVER OUR STORY
            </button>
          </div>

          {/* Quick Technical Accents */}
          <div className="mt-14 pt-8 border-t border-[#C6A56B]/15 grid grid-cols-3 gap-6 text-left">
            <div>
              <p className="text-2xl sm:text-3xl font-serif text-[#F5F2EC] font-normal">860 <span className="text-xs text-[#C6A56B] font-sans uppercase">HP</span></p>
              <p className="text-[10px] tracking-widest text-[#A9A49A] uppercase mt-1">Twin-Turbo Hybrid</p>
            </div>
            <div>
              <p className="text-2xl sm:text-3xl font-serif text-[#F5F2EC] font-normal">2.6 <span className="text-xs text-[#C6A56B] font-sans uppercase">Sec</span></p>
              <p className="text-[10px] tracking-widest text-[#A9A49A] uppercase mt-1">0–60 MPH Launch</p>
            </div>
            <div>
              <p className="text-2xl sm:text-3xl font-serif text-[#F5F2EC] font-normal">218 <span className="text-xs text-[#C6A56B] font-sans uppercase">MPH</span></p>
              <p className="text-[10px] tracking-widest text-[#A9A49A] uppercase mt-1">V-Max Velocity</p>
            </div>
          </div>
        </div>
      </div>

      {/* Animated Scroll-Down Indicator */}
      <a
        href="#highlights"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2 text-[#A9A49A] hover:text-[#C6A56B] transition-colors group cursor-pointer"
        aria-label="Scroll to highlights"
      >
        <span className="text-[10px] uppercase tracking-[0.3em] font-medium opacity-80 group-hover:opacity-100">
          Scroll
        </span>
        <div className="w-5 h-8 border border-[#C6A56B]/30 rounded-full flex items-start justify-center p-1">
          <div className="w-1 h-2 bg-[#C6A56B] rounded-full animate-bounce" />
        </div>
      </a>
    </section>
  );
};
