import React, { useState } from 'react';
import { ArrowRight, Check, ShieldCheck, Globe, Instagram, Linkedin, Twitter, Youtube } from 'lucide-react';
import { BrandLogo } from './BrandLogo';

interface FooterProps {
  onOpenLegal: (title: string, content: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenLegal }) => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newsletterEmail)) {
      setSubscribed(true);
      setNewsletterEmail('');
    }
  };

  const privacyContent = `
    Vanta Motors ("we", "us", or "our") respects the privacy and confidentiality of our private patrons and clients. 
    Any personal information gathered through direct commission inquiries, consultation requests, or newsletter registrations is securely handled in accordance with the highest international data protection standards. 
    We will never sell, transfer, or disclose client identity credentials to third parties without prior explicit authorization.
  `;

  const termsContent = `
    All commission contracts and build allocations issued by Vanta Motors are subject to private bespoke terms agreed between the buyer and the atelier. 
    Production slots are confirmed upon signature and deposit execution. Vehicle specifications, horsepower ratings, and performance metrics are calibrated individually according to the client's homologation market requirements.
  `;

  const cookieContent = `
    Vanta Motors utilizes essential technical cookies to ensure optimal visual performance, secure forms, and responsive typography. 
    We do not implement intrusive advertising trackers or sell browsing profiles. You may modify your browser settings at any time.
  `;

  return (
    <footer className="bg-[#0D0D0C] text-[#F5F2EC] border-t border-[#C6A56B]/25 pt-16 pb-12 relative">
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        {/* Top Newsletter & Brand Statement Bar */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 pb-16 border-b border-[#C6A56B]/15 items-center">
          <div className="lg:col-span-6">
            <BrandLogo size="lg" />
            <p className="text-sm text-[#A9A49A] font-light leading-relaxed mt-4 max-w-md">
              Pioneering the intersection of aerodynamic sculpture and bespoke mechanical emotion. Crafted without compromise for those who demand the pinnacle.
            </p>
          </div>

          <div className="lg:col-span-6">
            <div className="bg-[#161514] border border-[#C6A56B]/20 rounded-lg p-6">
              <span className="text-[10px] tracking-[0.25em] uppercase font-semibold text-[#C6A56B] block mb-1">
                PRIVATE CLIENT DISPATCH
              </span>
              <h4 className="font-serif text-lg text-[#F5F2EC] mb-2 font-normal">
                Receive Private Allocation Bulletins
              </h4>
              <p className="text-xs text-[#A9A49A] mb-4">
                Be among the first to receive confidential notices regarding limited coachbuild production runs and invite-only dynamic driving summits.
              </p>

              {subscribed ? (
                <div className="flex items-center gap-2 p-3 bg-[#22211F] border border-[#C6A56B]/40 rounded text-xs text-[#C6A56B]">
                  <Check className="w-4 h-4" />
                  <span>Welcome to the Vanta Dispatch. Invitation confirmed.</span>
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="flex gap-2">
                  <input
                    type="email"
                    required
                    value={newsletterEmail}
                    onChange={(e) => setNewsletterEmail(e.target.value)}
                    placeholder="Enter your private email..."
                    className="flex-1 bg-[#22211F] border border-[#C6A56B]/20 text-xs text-[#F5F2EC] px-4 py-2.5 rounded-sm focus:outline-none focus:border-[#C6A56B]"
                  />
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-[#C6A56B] text-[#111110] text-xs font-semibold uppercase tracking-wider rounded-sm hover:bg-[#d6b77e] transition-colors cursor-pointer shrink-0"
                  >
                    Subscribe
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>

        {/* Structured Navigation Columns */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 py-12 border-b border-[#C6A56B]/15 text-xs">
          {/* Col 1: Vehicles */}
          <div>
            <h5 className="font-serif text-sm text-[#F5F2EC] uppercase tracking-wider mb-4">
              Current Fleet
            </h5>
            <ul className="space-y-2.5 text-[#A9A49A]">
              <li><a href="#collection" className="hover:text-[#C6A56B] transition-colors">Vanta Spectre GT</a></li>
              <li><a href="#collection" className="hover:text-[#C6A56B] transition-colors">Vanta Sovereign Aeromax</a></li>
              <li><a href="#collection" className="hover:text-[#C6A56B] transition-colors">Vanta Valkyrie Grand Tourer</a></li>
              <li><a href="#collection" className="hover:text-[#C6A56B] transition-colors">Vanta Valo Spider</a></li>
              <li><a href="#collection" className="hover:text-[#C6A56B] transition-colors">Vanta Apex CrossTourer</a></li>
            </ul>
          </div>

          {/* Col 2: The Atelier */}
          <div>
            <h5 className="font-serif text-sm text-[#F5F2EC] uppercase tracking-wider mb-4">
              The Atelier
            </h5>
            <ul className="space-y-2.5 text-[#A9A49A]">
              <li><a href="#story" className="hover:text-[#C6A56B] transition-colors">Design & Aerodynamics</a></li>
              <li><a href="#story" className="hover:text-[#C6A56B] transition-colors">Bespoke Commissioning</a></li>
              <li><a href="#experience" className="hover:text-[#C6A56B] transition-colors">Craftsmanship Heritage</a></li>
              <li><a href="#gallery" className="hover:text-[#C6A56B] transition-colors">Archive of Details</a></li>
              <li><a href="#highlights" className="hover:text-[#C6A56B] transition-colors">Quality Standard</a></li>
            </ul>
          </div>

          {/* Col 3: Private Services */}
          <div>
            <h5 className="font-serif text-sm text-[#F5F2EC] uppercase tracking-wider mb-4">
              Private Client
            </h5>
            <ul className="space-y-2.5 text-[#A9A49A]">
              <li><a href="#contact" className="hover:text-[#C6A56B] transition-colors">Mayfair Concierge Desk</a></li>
              <li><a href="#experience" className="hover:text-[#C6A56B] transition-colors">Circuit Drive Bookings</a></li>
              <li><a href="#contact" className="hover:text-[#C6A56B] transition-colors">Global Enclosed Logistics</a></li>
              <li><a href="#contact" className="hover:text-[#C6A56B] transition-colors">Certified Atelier Care</a></li>
            </ul>
          </div>

          {/* Col 4: International Salons */}
          <div>
            <h5 className="font-serif text-sm text-[#F5F2EC] uppercase tracking-wider mb-4">
              Global Salons
            </h5>
            <ul className="space-y-2.5 text-[#A9A49A]">
              <li><span className="text-[#F5F2EC]">London</span> · Berkeley Sq, Mayfair</li>
              <li><span className="text-[#F5F2EC]">Geneva</span> · Rue du Rhône</li>
              <li><span className="text-[#F5F2EC]">Monaco</span> · Quai Antoine 1er</li>
              <li><span className="text-[#F5F2EC]">New York</span> · Madison Avenue</li>
              <li><span className="text-[#F5F2EC]">Tokyo</span> · Ginza 6-Chome</li>
            </ul>
          </div>
        </div>

        {/* Bottom Legal & Copyright Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#A9A49A]/80">
          <div className="flex flex-wrap items-center gap-6">
            <span>© {new Date().getFullYear()} VANTA MOTORS. All rights reserved.</span>
            <button
              onClick={() => onOpenLegal('Privacy Policy', privacyContent)}
              className="hover:text-[#C6A56B] transition-colors cursor-pointer underline underline-offset-4"
            >
              Privacy Policy
            </button>
            <button
              onClick={() => onOpenLegal('Terms of Commission', termsContent)}
              className="hover:text-[#C6A56B] transition-colors cursor-pointer underline underline-offset-4"
            >
              Terms of Commission
            </button>
            <button
              onClick={() => onOpenLegal('Cookie Discretion', cookieContent)}
              className="hover:text-[#C6A56B] transition-colors cursor-pointer underline underline-offset-4"
            >
              Cookie Discretion
            </button>
          </div>

          {/* Luxury Social Icons */}
          <div className="flex items-center gap-4 text-[#A9A49A]">
            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="hover:text-[#C6A56B] transition-colors p-1" aria-label="Instagram">
              <Instagram className="w-4 h-4" />
            </a>
            <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="hover:text-[#C6A56B] transition-colors p-1" aria-label="LinkedIn">
              <Linkedin className="w-4 h-4" />
            </a>
            <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" className="hover:text-[#C6A56B] transition-colors p-1" aria-label="YouTube">
              <Youtube className="w-4 h-4" />
            </a>
            <a href="https://x.com" target="_blank" rel="noopener noreferrer" className="hover:text-[#C6A56B] transition-colors p-1" aria-label="X (formerly Twitter)">
              <Twitter className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
