import React from 'react';
import { Star, Quote } from 'lucide-react';
import { TESTIMONIALS } from '../data/vehicles';
import { SafeImage } from './SafeImage';

export const Testimonials: React.FC = () => {
  return (
    <section className="py-24 md:py-32 bg-[#111110] relative">
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center justify-center gap-3 mb-3">
            <span className="w-6 h-[1px] bg-[#C6A56B]" />
            <span className="text-[11px] font-semibold tracking-[0.28em] uppercase text-[#C6A56B]">
              CLIENT REFLECTIONS
            </span>
            <span className="w-6 h-[1px] bg-[#C6A56B]" />
          </div>
          <h2 className="font-serif text-3xl sm:text-5xl text-[#F5F2EC] font-normal leading-tight">
            A Personal Experience, <br />
            <span className="italic text-[#F5F2EC]/90">Every Time.</span>
          </h2>
          <p className="text-xs text-[#A9A49A]/80 uppercase tracking-widest mt-3">
            Illustrative Patron Testimonials · Sample Client Feedback
          </p>
        </div>

        {/* 3 Dark Luxury Testimonial Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((test) => (
            <div
              key={test.id}
              className="bg-[#22211F] border border-[#C6A56B]/20 rounded-xl p-8 flex flex-col justify-between hover:border-[#C6A56B]/50 transition-all duration-300 shadow-xl group"
            >
              <div>
                {/* Gold Stars (Clearly marked as illustrative) */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-1" title="5-Star Rating (Illustrative Demonstration)">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-[#C6A56B] text-[#C6A56B]" />
                    ))}
                  </div>
                  <Quote className="w-6 h-6 text-[#C6A56B]/30 group-hover:text-[#C6A56B]/60 transition-colors" />
                </div>

                {/* Quote */}
                <p className="text-sm sm:text-base text-[#F5F2EC]/90 font-light italic leading-relaxed mb-8">
                  "{test.quote}"
                </p>
              </div>

              {/* Client Profile */}
              <div className="pt-6 border-t border-[#C6A56B]/15 flex items-center gap-4">
                <div className="w-12 h-12 rounded-full overflow-hidden border border-[#C6A56B]/40 shrink-0 bg-[#1B1A18]">
                  <SafeImage
                    src={test.avatarUrl}
                    alt={test.clientName}
                    className="w-full h-full object-cover"
                    fallbackTitle={test.clientName}
                    fallbackCategory="Patron"
                  />
                </div>
                <div>
                  <h4 className="font-serif text-base text-[#F5F2EC] font-medium">
                    {test.clientName}
                  </h4>
                  <p className="text-[11px] text-[#A9A49A]">
                    {test.clientRole} · <span className="text-[#C6A56B]">{test.location}</span>
                  </p>
                  <p className="text-[10px] text-[#A9A49A]/70 uppercase tracking-wider mt-0.5">
                    {test.modelCommissioned}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
