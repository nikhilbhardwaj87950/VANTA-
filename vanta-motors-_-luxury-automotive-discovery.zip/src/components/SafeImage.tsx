import React, { useState } from 'react';

interface SafeImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  fallbackTitle?: string;
  fallbackCategory?: string;
}

export const SafeImage: React.FC<SafeImageProps> = ({
  src,
  alt,
  className = '',
  fallbackTitle = 'VANTA MOTORS',
  fallbackCategory = 'Bespoke Automotive',
  ...props
}) => {
  const [hasError, setHasError] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  if (hasError || !src) {
    return (
      <div className={`relative flex flex-col items-center justify-center overflow-hidden bg-gradient-to-br from-[#1B1A18] via-[#151412] to-[#0A0A09] text-center p-6 border border-[#C6A56B]/20 ${className}`}>
        {/* Subtle geometric luxury blueprint grid */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#C6A56B_1px,transparent_1px)] [background-size:16px_16px]" />
        
        {/* Sleek luxury automotive silhouette SVG */}
        <svg
          className="w-24 h-14 text-[#C6A56B] mb-3 opacity-80"
          viewBox="0 0 100 45"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          {/* Aerodynamic roofline & body */}
          <path d="M5 32 Q15 30 22 24 L35 15 Q48 10 70 14 L85 24 Q95 28 98 32 H5 Z" fill="rgba(198,165,107,0.06)" />
          {/* Greenhouse glass */}
          <path d="M36 17 Q48 13 65 16 L78 24 H30 Z" stroke="#C6A56B" strokeWidth="1" />
          {/* Wheel arches */}
          <path d="M18 32 A7 7 0 0 1 32 32" stroke="#C6A56B" strokeWidth="1.8" />
          <path d="M72 32 A7 7 0 0 1 86 32" stroke="#C6A56B" strokeWidth="1.8" />
          {/* Headlight beam */}
          <line x1="88" y1="26" x2="98" y2="28" stroke="#F5F2EC" strokeWidth="1.5" />
        </svg>

        <div className="relative z-10">
          <p className="text-[10px] tracking-[0.25em] uppercase text-[#C6A56B] font-medium mb-1">
            {fallbackCategory}
          </p>
          <p className="text-sm tracking-widest uppercase font-serif text-[#F5F2EC]">
            {fallbackTitle}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full overflow-hidden">
      {isLoading && (
        <div className="absolute inset-0 bg-[#1B1A18] animate-pulse flex items-center justify-center">
          <div className="w-8 h-8 rounded-full border border-[#C6A56B]/30 border-t-[#C6A56B] animate-spin" />
        </div>
      )}
      <img
        src={src}
        alt={alt || fallbackTitle}
        className={`${className} ${isLoading ? 'opacity-0' : 'opacity-100'} transition-opacity duration-500`}
        onError={() => setHasError(true)}
        onLoad={() => setIsLoading(false)}
        loading="lazy"
        {...props}
      />
    </div>
  );
};
