import React, { useState } from 'react';
import { Mail, Phone, MapPin, Clock, Send, CheckCircle2, Shield, Mic } from 'lucide-react';
import { VEHICLES } from '../data/vehicles';
import { VoiceTranscriber } from './VoiceTranscriber';

interface EnquirySectionProps {
  selectedVehiclePreset?: string;
}

export const EnquirySection: React.FC<EnquirySectionProps> = ({ selectedVehiclePreset }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    vehicle: selectedVehiclePreset || 'Vanta Spectre GT',
    timeline: 'Immediate (Within 30 Days)',
    message: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Sync if preset changes
  React.useEffect(() => {
    if (selectedVehiclePreset) {
      setFormData((prev) => ({ ...prev, vehicle: selectedVehiclePreset }));
    }
  }, [selectedVehiclePreset]);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) newErrors.name = 'Full name is required.';
    if (!formData.email.trim()) {
      newErrors.email = 'Email address is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address.';
    }
    if (!formData.phone.trim()) {
      newErrors.phone = 'Contact telephone is required for client identity.';
    }
    if (!formData.message.trim() || formData.message.length < 10) {
      newErrors.message = 'Please provide brief details regarding your commission or question (min 10 characters).';
    }
    return newErrors;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setErrors({});
    setIsSubmitting(true);

    // Simulate luxury concierge dispatch
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 800);
  };

  return (
    <section id="contact" className="py-24 md:py-32 bg-[#161514] border-t border-[#C6A56B]/20 relative">
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Left Column: Direct Concierge & Showroom Information */}
          <div className="lg:col-span-5 flex flex-col justify-between">
            <div>
              <div className="inline-flex items-center gap-3 mb-4">
                <span className="w-6 h-[1px] bg-[#C6A56B]" />
                <span className="text-[11px] font-semibold tracking-[0.28em] uppercase text-[#C6A56B]">
                  BESPOKE ATELIER LIAISON
                </span>
              </div>

              <h2 className="font-serif text-3xl sm:text-5xl text-[#F5F2EC] font-normal leading-tight mb-6">
                Your Next <br />
                Extraordinary Drive <br />
                <span className="italic text-[#F5F2EC]/90">Starts Here.</span>
              </h2>

              <p className="text-sm sm:text-base text-[#A9A49A] font-light leading-relaxed mb-10">
                Whether commissioning a bespoke vehicle, securing a private circuit drive, or inquiring regarding build allocations, our Private Client Directors are at your service.
              </p>

              {/* Concierge Contact Details */}
              <div className="space-y-6 mb-10">
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-[#22211F] border border-[#C6A56B]/20 rounded-sm text-[#C6A56B] shrink-0">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-[10px] tracking-widest uppercase text-[#A9A49A] font-medium">Direct Concierge Desk</p>
                    <a href="tel:+442079460198" className="text-sm sm:text-base font-serif text-[#F5F2EC] hover:text-[#C6A56B] transition-colors">
                      +44 (0) 20 7946 0198
                    </a>
                    <p className="text-xs text-[#A9A49A]/70 mt-0.5">Available 24/7 for Private Patrons</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="p-3 bg-[#22211F] border border-[#C6A56B]/20 rounded-sm text-[#C6A56B] shrink-0">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-[10px] tracking-widest uppercase text-[#A9A49A] font-medium">Commission Inquiries</p>
                    <a href="mailto:concierge@vantamotors.com" className="text-sm sm:text-base font-serif text-[#F5F2EC] hover:text-[#C6A56B] transition-colors">
                      concierge@vantamotors.com
                    </a>
                    <p className="text-xs text-[#A9A49A]/70 mt-0.5">Encrypted private client channel</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="p-3 bg-[#22211F] border border-[#C6A56B]/20 rounded-sm text-[#C6A56B] shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-[10px] tracking-widest uppercase text-[#A9A49A] font-medium">Flagship Mayfair Atelier</p>
                    <p className="text-sm sm:text-base font-serif text-[#F5F2EC]">
                      14 Berkeley Square, Mayfair, London W1J 5AW
                    </p>
                    <p className="text-xs text-[#A9A49A]/70 mt-0.5">By Private Appointment Only</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Privacy pledge */}
            <div className="p-4 bg-[#1B1A18] border border-[#C6A56B]/15 rounded-lg flex items-center gap-3 text-xs text-[#A9A49A]">
              <Shield className="w-5 h-5 text-[#C6A56B] shrink-0" />
              <span>We value your discretion. Your personal credentials will never be shared or distributed.</span>
            </div>
          </div>

          {/* Right Column: Interactive Form */}
          <div className="lg:col-span-7 bg-[#1B1A18] border border-[#C6A56B]/30 rounded-xl p-8 sm:p-10 shadow-2xl relative">
            {isSubmitted ? (
              <div className="py-12 text-center animate-in fade-in zoom-in-95 duration-300">
                <div className="w-16 h-16 rounded-full bg-[#C6A56B]/15 border border-[#C6A56B] flex items-center justify-center mx-auto mb-6">
                  <CheckCircle2 className="w-8 h-8 text-[#C6A56B]" />
                </div>
                <h3 className="font-serif text-3xl text-[#F5F2EC] mb-3">
                  Inquiry Dispatched
                </h3>
                <p className="text-sm text-[#A9A49A] max-w-md mx-auto mb-6">
                  Thank you, <strong className="text-[#F5F2EC]">{formData.name}</strong>. Your expression of interest regarding the <strong className="text-[#C6A56B]">{formData.vehicle}</strong> has been received by our Mayfair Client Desk.
                </p>
                <div className="bg-[#22211F] border border-[#C6A56B]/20 rounded p-4 text-xs text-[#A9A49A] max-w-sm mx-auto mb-8 text-left space-y-1">
                  <p><span className="text-[#F5F2EC] font-medium">Contact:</span> {formData.email}</p>
                  <p><span className="text-[#F5F2EC] font-medium">Phone:</span> {formData.phone}</p>
                  <p><span className="text-[#F5F2EC] font-medium">Timeline:</span> {formData.timeline}</p>
                </div>
                <button
                  onClick={() => {
                    setIsSubmitted(false);
                    setFormData({
                      name: '',
                      email: '',
                      phone: '',
                      vehicle: VEHICLES[0].name,
                      timeline: 'Immediate (Within 30 Days)',
                      message: ''
                    });
                  }}
                  className="px-8 py-3 text-xs font-semibold uppercase tracking-[0.2em] bg-[#C6A56B] text-[#111110] hover:bg-[#d6b77e] transition-colors rounded-sm"
                >
                  Send Another Inquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6" noValidate>
                <div>
                  <h3 className="font-serif text-2xl text-[#F5F2EC] mb-1">
                    Direct Atelier Inquiry
                  </h3>
                  <p className="text-xs text-[#A9A49A]">
                    Fill in your details below to begin your consultation.
                  </p>
                </div>

                {/* Name & Email */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="text-[11px] uppercase tracking-wider text-[#A9A49A] block mb-1.5 font-medium">
                      Your Full Name *
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g. Lord Alexander Montgomery"
                      className={`w-full bg-[#22211F] border text-[#F5F2EC] px-4 py-3 rounded-sm text-sm focus:outline-none transition-colors ${
                        errors.name ? 'border-red-500/80 focus:border-red-500' : 'border-[#C6A56B]/25 focus:border-[#C6A56B]'
                      }`}
                    />
                    {errors.name && <p className="text-red-400 text-[11px] mt-1">{errors.name}</p>}
                  </div>

                  <div>
                    <label className="text-[11px] uppercase tracking-wider text-[#A9A49A] block mb-1.5 font-medium">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="alexander@montgomery.co"
                      className={`w-full bg-[#22211F] border text-[#F5F2EC] px-4 py-3 rounded-sm text-sm focus:outline-none transition-colors ${
                        errors.email ? 'border-red-500/80 focus:border-red-500' : 'border-[#C6A56B]/25 focus:border-[#C6A56B]'
                      }`}
                    />
                    {errors.email && <p className="text-red-400 text-[11px] mt-1">{errors.email}</p>}
                  </div>
                </div>

                {/* Phone & Model Selection */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="text-[11px] uppercase tracking-wider text-[#A9A49A] block mb-1.5 font-medium">
                      Telephone / Mobile *
                    </label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="+44 20 7946 0912"
                      className={`w-full bg-[#22211F] border text-[#F5F2EC] px-4 py-3 rounded-sm text-sm focus:outline-none transition-colors ${
                        errors.phone ? 'border-red-500/80 focus:border-red-500' : 'border-[#C6A56B]/25 focus:border-[#C6A56B]'
                      }`}
                    />
                    {errors.phone && <p className="text-red-400 text-[11px] mt-1">{errors.phone}</p>}
                  </div>

                  <div>
                    <label className="text-[11px] uppercase tracking-wider text-[#A9A49A] block mb-1.5 font-medium">
                      Vehicle of Interest
                    </label>
                    <select
                      value={formData.vehicle}
                      onChange={(e) => setFormData({ ...formData, vehicle: e.target.value })}
                      className="w-full bg-[#22211F] border border-[#C6A56B]/25 text-[#F5F2EC] px-4 py-3 rounded-sm text-sm focus:outline-none focus:border-[#C6A56B]"
                    >
                      {VEHICLES.map((car) => (
                        <option key={car.id} value={car.name} className="bg-[#1B1A18] text-[#F5F2EC]">
                          {car.name} ({car.category})
                        </option>
                      ))}
                      <option value="Bespoke Coachbuild (One-Off)" className="bg-[#1B1A18] text-[#F5F2EC]">
                        Bespoke Coachbuild (One-Off Special Project)
                      </option>
                    </select>
                  </div>
                </div>

                {/* Timeline radio options */}
                <div>
                  <label className="text-[11px] uppercase tracking-wider text-[#A9A49A] block mb-2 font-medium">
                    Anticipated Acquisition Timeline
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    {[
                      'Immediate (Within 30 Days)',
                      'Within 3 to 6 Months',
                      'Future Collection Planning'
                    ].map((time) => (
                      <button
                        type="button"
                        key={time}
                        onClick={() => setFormData({ ...formData, timeline: time })}
                        className={`py-2 px-3 text-xs rounded border text-center transition-all ${
                          formData.timeline === time
                            ? 'border-[#C6A56B] bg-[#22211F] text-[#C6A56B] font-medium'
                            : 'border-[#C6A56B]/15 bg-[#161514] text-[#A9A49A] hover:border-[#C6A56B]/30'
                        }`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Message & Voice Dictation */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-[11px] uppercase tracking-wider text-[#A9A49A] font-medium">
                      Message or Special Inquiries *
                    </label>
                    <VoiceTranscriber
                      buttonLabel="Voice Dictate"
                      placeholderPrompt="Transcribe spoken client automotive inquiry detailing desired bespoke options, timeline, or test drive request."
                      onTranscriptionComplete={(text) => {
                        setFormData((prev) => ({
                          ...prev,
                          message: prev.message ? `${prev.message} ${text}` : text,
                        }));
                        if (errors.message) {
                          setErrors((prev) => {
                            const newErrors = { ...prev };
                            delete newErrors.message;
                            return newErrors;
                          });
                        }
                      }}
                    />
                  </div>
                  <textarea
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Tell us about your preferred specifications, test drive requests, or delivery requirements (or click 'Voice Dictate' to speak)..."
                    className={`w-full bg-[#22211F] border text-[#F5F2EC] p-4 rounded-sm text-sm focus:outline-none transition-colors ${
                      errors.message ? 'border-red-500/80 focus:border-red-500' : 'border-[#C6A56B]/25 focus:border-[#C6A56B]'
                    }`}
                  />
                  {errors.message && <p className="text-red-400 text-[11px] mt-1">{errors.message}</p>}
                </div>

                {/* Submit button */}
                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full inline-flex items-center justify-center gap-3 py-4 text-xs font-semibold uppercase tracking-[0.22em] text-[#111110] bg-[#C6A56B] hover:bg-[#d6b77e] transition-all duration-300 rounded-sm cursor-pointer shadow-xl disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <span>TRANSMITTING INQUIRY...</span>
                    ) : (
                      <>
                        <span>TRANSMIT BESPOKE INQUIRY</span>
                        <Send className="w-3.5 h-3.5" />
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
