import React from 'react';
import { Sparkles, ShieldCheck, Compass, Award } from 'lucide-react';
import { BRAND_HIGHLIGHTS } from '../data/vehicles';

export const BrandHighlights: React.FC = () => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-[#C6A56B]" />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-5 h-5 text-[#C6A56B]" />;
      case 'Compass':
        return <Compass className="w-5 h-5 text-[#C6A56B]" />;
      case 'Award':
      default:
        return <Award className="w-5 h-5 text-[#C6A56B]" />;
    }
  };

  return (
    <section id="highlights" className="relative z-20 bg-[#161514] border-y border-[#C6A56B]/20 py-12 md:py-16">
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-10 divide-y sm:divide-y-0 lg:divide-x divide-[#C6A56B]/15">
          {BRAND_HIGHLIGHTS.map((item, index) => (
            <div
              key={item.title}
              className={`flex flex-col pt-6 sm:pt-0 ${
                index > 0 ? 'lg:pl-8' : ''
              }`}
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2.5 rounded-sm bg-[#22211F] border border-[#C6A56B]/25">
                  {getIcon(item.icon)}
                </div>
                <h3 className="font-serif text-lg text-[#F5F2EC] font-normal tracking-wide">
                  {item.title}
                </h3>
              </div>
              <p className="text-xs sm:text-sm text-[#A9A49A] font-light leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
