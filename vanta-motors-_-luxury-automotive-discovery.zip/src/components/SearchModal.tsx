import React, { useState, useEffect, useRef } from 'react';
import { Search, X, ArrowRight, Gauge, Zap } from 'lucide-react';
import { VEHICLES, Vehicle } from '../data/vehicles';
import { VoiceTranscriber } from './VoiceTranscriber';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectVehicle: (vehicle: Vehicle) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectVehicle
}) => {
  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape') onClose();
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
    }
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const categories = ['all', 'Grand Tourer', 'Saloon', 'Coupe', 'Roadster'];

  const filtered = VEHICLES.filter((car) => {
    const matchesCategory =
      activeCategory === 'all' ||
      car.category.toLowerCase().includes(activeCategory.toLowerCase());
    const matchesQuery =
      car.name.toLowerCase().includes(query.toLowerCase()) ||
      car.category.toLowerCase().includes(query.toLowerCase()) ||
      car.powertrain.toLowerCase().includes(query.toLowerCase()) ||
      car.features.some((f) => f.toLowerCase().includes(query.toLowerCase()));
    return matchesCategory && matchesQuery;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-black/80 backdrop-blur-md transition-all">
      <div 
        className="w-full max-w-2xl bg-[#1B1A18] border border-[#C6A56B]/30 shadow-2xl rounded-lg overflow-hidden animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="relative flex items-center px-6 py-4 border-b border-[#C6A56B]/20 bg-[#161514] gap-2">
          <Search className="w-5 h-5 text-[#C6A56B] shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by vehicle model, powertrain, or bespoke features..."
            className="flex-1 bg-transparent text-[#F5F2EC] placeholder-[#A9A49A]/60 text-sm sm:text-base focus:outline-none"
          />
          <VoiceTranscriber
            buttonLabel="Voice"
            placeholderPrompt="Transcribe spoken luxury automotive search keywords such as model names, hybrid specs, or performance."
            onTranscriptionComplete={(text) => setQuery(text)}
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-[#A9A49A] hover:text-[#F5F2EC] transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1.5 rounded text-[#A9A49A] hover:text-[#C6A56B] hover:bg-[#22211F] transition-all ml-1"
            title="Close Search (Esc)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter chips */}
        <div className="flex items-center gap-2 px-6 py-3 border-b border-[#C6A56B]/10 overflow-x-auto text-xs">
          <span className="text-[#A9A49A] font-medium mr-1 uppercase tracking-wider text-[10px]">Filter:</span>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1 rounded-sm text-xs font-medium uppercase tracking-wider transition-colors ${
                activeCategory === cat
                  ? 'bg-[#C6A56B] text-[#111110]'
                  : 'bg-[#22211F] text-[#A9A49A] hover:text-[#F5F2EC] border border-[#C6A56B]/20'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Results list */}
        <div className="max-h-[60vh] overflow-y-auto divide-y divide-[#C6A56B]/10 p-2">
          {filtered.length === 0 ? (
            <div className="py-12 text-center text-[#A9A49A]">
              <p className="text-sm">No vehicles found matching "{query}".</p>
              <p className="text-xs text-[#A9A49A]/60 mt-1">Try searching for "Spectre", "V12", "Aeromax", or "Hybrid".</p>
            </div>
          ) : (
            filtered.map((vehicle) => (
              <div
                key={vehicle.id}
                onClick={() => {
                  onSelectVehicle(vehicle);
                  onClose();
                }}
                className="group flex items-center justify-between p-4 rounded hover:bg-[#22211F] cursor-pointer transition-all border border-transparent hover:border-[#C6A56B]/30"
              >
                <div className="flex items-center gap-4">
                  <div className="w-20 h-14 bg-[#111110] rounded overflow-hidden shrink-0 border border-[#C6A56B]/20">
                    <img
                      src={vehicle.imageUrl}
                      alt={vehicle.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] tracking-widest text-[#C6A56B] uppercase font-medium">
                        {vehicle.category}
                      </span>
                    </div>
                    <h4 className="font-serif text-[#F5F2EC] text-base font-medium group-hover:text-[#C6A56B] transition-colors">
                      {vehicle.name}
                    </h4>
                    <div className="flex items-center gap-4 text-xs text-[#A9A49A] mt-1">
                      <span className="flex items-center gap-1">
                        <Zap className="w-3 h-3 text-[#C6A56B]" /> {vehicle.horsepower}
                      </span>
                      <span className="flex items-center gap-1">
                        <Gauge className="w-3 h-3 text-[#C6A56B]" /> 0-60: {vehicle.acceleration}
                      </span>
                      <span>From {vehicle.startingPrice}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center text-[#A9A49A] group-hover:text-[#C6A56B] group-hover:translate-x-1 transition-all">
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
