import React, { useState } from 'react';
import { X, ArrowRight, ArrowLeftRight, Check, Zap, Gauge, Compass, Shield, Calendar, Sparkles } from 'lucide-react';
import { VEHICLES, Vehicle } from '../data/vehicles';
import { SafeImage } from './SafeImage';

interface CompareModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialVehicleAId?: string;
  initialVehicleBId?: string;
  onSelectForEnquiry: (vehicleName: string) => void;
  onBookConsultation: (vehicleName: string) => void;
  onViewDetails: (vehicle: Vehicle) => void;
}

export const CompareModal: React.FC<CompareModalProps> = ({
  isOpen,
  onClose,
  initialVehicleAId,
  initialVehicleBId,
  onSelectForEnquiry,
  onBookConsultation,
  onViewDetails
}) => {
  const [vehicleAId, setVehicleAId] = useState<string>(
    initialVehicleAId || VEHICLES[0].id
  );
  const [vehicleBId, setVehicleBId] = useState<string>(
    initialVehicleBId || (VEHICLES[1] ? VEHICLES[1].id : VEHICLES[0].id)
  );
  const [highlightDifferences, setHighlightDifferences] = useState(false);

  // Keep in sync if initial props change
  React.useEffect(() => {
    if (initialVehicleAId) setVehicleAId(initialVehicleAId);
    if (initialVehicleBId) setVehicleBId(initialVehicleBId);
  }, [initialVehicleAId, initialVehicleBId]);

  if (!isOpen) return null;

  const carA = VEHICLES.find((v) => v.id === vehicleAId) || VEHICLES[0];
  const carB = VEHICLES.find((v) => v.id === vehicleBId) || VEHICLES[1] || VEHICLES[0];

  const handleSwap = () => {
    const temp = vehicleAId;
    setVehicleAId(vehicleBId);
    setVehicleBId(temp);
  };

  // Helper to determine numerical advantage for styling
  const getHorsepowerVal = (hpStr: string) => parseInt(hpStr.replace(/\D/g, ''), 10) || 0;
  const getAccelVal = (accStr: string) => parseFloat(accStr.replace('s', '')) || 0;
  const getTopSpeedVal = (speedStr: string) => parseInt(speedStr.replace(/\D/g, ''), 10) || 0;

  const hpA = getHorsepowerVal(carA.horsepower);
  const hpB = getHorsepowerVal(carB.horsepower);

  const accelA = getAccelVal(carA.acceleration);
  const accelB = getAccelVal(carB.acceleration);

  const speedA = getTopSpeedVal(carA.topSpeed);
  const speedB = getTopSpeedVal(carB.topSpeed);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-md overflow-y-auto">
      <div
        className="relative w-full max-w-5xl bg-[#1B1A18] border border-[#C6A56B]/30 rounded-xl overflow-hidden shadow-2xl my-6 flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#C6A56B]/20 bg-[#161514]">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#22211F] border border-[#C6A56B]/30 rounded text-[#C6A56B]">
              <ArrowLeftRight className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] tracking-[0.25em] uppercase font-semibold text-[#C6A56B]">
                SPECIFICATION MATRIX
              </span>
              <h2 className="font-serif text-xl sm:text-2xl text-[#F5F2EC]">
                Side-by-Side Model Comparison
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Highlight Differences toggle */}
            <button
              onClick={() => setHighlightDifferences(!highlightDifferences)}
              className={`hidden md:inline-flex items-center gap-2 px-3 py-1.5 rounded-sm text-xs transition-colors border ${
                highlightDifferences
                  ? 'bg-[#C6A56B] text-[#111110] border-[#C6A56B] font-medium'
                  : 'bg-[#22211F] text-[#A9A49A] border-[#C6A56B]/20 hover:text-[#F5F2EC]'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Highlight Differences</span>
            </button>

            {/* Swap Vehicles */}
            <button
              onClick={handleSwap}
              className="p-2 text-[#A9A49A] hover:text-[#C6A56B] bg-[#22211F] rounded border border-[#C6A56B]/20 transition-colors"
              title="Swap Left and Right Vehicles"
            >
              <ArrowLeftRight className="w-4 h-4" />
            </button>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-2 text-[#A9A49A] hover:text-[#C6A56B] bg-[#22211F] rounded border border-[#C6A56B]/20 transition-colors"
              aria-label="Close Comparison"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Comparison Content */}
        <div className="overflow-y-auto flex-1 p-4 sm:p-8 space-y-8">
          {/* Header Row: Vehicle Cards with Image & Selectors */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Vehicle A Selector & Card */}
            <div className="bg-[#22211F] border border-[#C6A56B]/25 rounded-lg p-5 flex flex-col justify-between shadow-lg">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[10px] uppercase tracking-widest text-[#C6A56B] font-semibold">
                    Model Selection A
                  </span>
                  <span className="text-xs text-[#A9A49A]">{carA.startingPrice}</span>
                </div>

                <select
                  value={vehicleAId}
                  onChange={(e) => setVehicleAId(e.target.value)}
                  className="w-full bg-[#161514] border border-[#C6A56B]/30 text-[#F5F2EC] px-3.5 py-2.5 rounded text-sm font-serif focus:outline-none focus:border-[#C6A56B] mb-4"
                >
                  {VEHICLES.map((v) => (
                    <option key={v.id} value={v.id} className="bg-[#1B1A18] text-[#F5F2EC]">
                      {v.name} ({v.category})
                    </option>
                  ))}
                </select>

                <div className="relative aspect-[16/9] rounded overflow-hidden border border-[#C6A56B]/20 bg-[#111110] mb-4">
                  <SafeImage
                    src={carA.imageUrl}
                    alt={carA.name}
                    className="w-full h-full object-cover"
                    fallbackTitle={carA.name}
                    fallbackCategory={carA.category}
                  />
                  <div className="absolute top-2 left-2 bg-[#111110]/80 backdrop-blur-sm px-2.5 py-0.5 rounded text-[10px] text-[#C6A56B] uppercase tracking-wider font-medium">
                    {carA.category}
                  </div>
                </div>

                <h3 className="font-serif text-xl sm:text-2xl text-[#F5F2EC]">{carA.name}</h3>
                <p className="text-xs text-[#A9A49A] italic mt-1 font-light line-clamp-2">"{carA.tagline}"</p>
              </div>

              <div className="mt-5 pt-4 border-t border-[#C6A56B]/15 flex items-center gap-2">
                <button
                  onClick={() => {
                    onSelectForEnquiry(carA.name);
                    onClose();
                  }}
                  className="flex-1 py-2 text-xs font-semibold uppercase tracking-wider bg-[#C6A56B] text-[#111110] hover:bg-[#d6b77e] transition-colors rounded-sm text-center"
                >
                  Inquire A
                </button>
                <button
                  onClick={() => {
                    onBookConsultation(carA.name);
                    onClose();
                  }}
                  className="px-3 py-2 text-xs font-medium uppercase tracking-wider bg-[#1B1A18] text-[#F5F2EC] border border-[#C6A56B]/30 hover:border-[#C6A56B] transition-colors rounded-sm"
                >
                  Test Drive
                </button>
              </div>
            </div>

            {/* Vehicle B Selector & Card */}
            <div className="bg-[#22211F] border border-[#C6A56B]/25 rounded-lg p-5 flex flex-col justify-between shadow-lg">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[10px] uppercase tracking-widest text-[#C6A56B] font-semibold">
                    Model Selection B
                  </span>
                  <span className="text-xs text-[#A9A49A]">{carB.startingPrice}</span>
                </div>

                <select
                  value={vehicleBId}
                  onChange={(e) => setVehicleBId(e.target.value)}
                  className="w-full bg-[#161514] border border-[#C6A56B]/30 text-[#F5F2EC] px-3.5 py-2.5 rounded text-sm font-serif focus:outline-none focus:border-[#C6A56B] mb-4"
                >
                  {VEHICLES.map((v) => (
                    <option key={v.id} value={v.id} className="bg-[#1B1A18] text-[#F5F2EC]">
                      {v.name} ({v.category})
                    </option>
                  ))}
                </select>

                <div className="relative aspect-[16/9] rounded overflow-hidden border border-[#C6A56B]/20 bg-[#111110] mb-4">
                  <SafeImage
                    src={carB.imageUrl}
                    alt={carB.name}
                    className="w-full h-full object-cover"
                    fallbackTitle={carB.name}
                    fallbackCategory={carB.category}
                  />
                  <div className="absolute top-2 left-2 bg-[#111110]/80 backdrop-blur-sm px-2.5 py-0.5 rounded text-[10px] text-[#C6A56B] uppercase tracking-wider font-medium">
                    {carB.category}
                  </div>
                </div>

                <h3 className="font-serif text-xl sm:text-2xl text-[#F5F2EC]">{carB.name}</h3>
                <p className="text-xs text-[#A9A49A] italic mt-1 font-light line-clamp-2">"{carB.tagline}"</p>
              </div>

              <div className="mt-5 pt-4 border-t border-[#C6A56B]/15 flex items-center gap-2">
                <button
                  onClick={() => {
                    onSelectForEnquiry(carB.name);
                    onClose();
                  }}
                  className="flex-1 py-2 text-xs font-semibold uppercase tracking-wider bg-[#C6A56B] text-[#111110] hover:bg-[#d6b77e] transition-colors rounded-sm text-center"
                >
                  Inquire B
                </button>
                <button
                  onClick={() => {
                    onBookConsultation(carB.name);
                    onClose();
                  }}
                  className="px-3 py-2 text-xs font-medium uppercase tracking-wider bg-[#1B1A18] text-[#F5F2EC] border border-[#C6A56B]/30 hover:border-[#C6A56B] transition-colors rounded-sm"
                >
                  Test Drive
                </button>
              </div>
            </div>
          </div>

          {/* Table-based Detailed Comparison Grid */}
          <div className="border border-[#C6A56B]/20 rounded-xl overflow-hidden bg-[#161514]">
            {/* Table Header Section: Key Performance Metrics */}
            <div className="bg-[#22211F] px-6 py-3 border-b border-[#C6A56B]/20 flex items-center justify-between">
              <span className="text-[11px] font-semibold tracking-[0.25em] uppercase text-[#C6A56B]">
                1. DYNAMIC PERFORMANCE
              </span>
              <span className="text-xs text-[#A9A49A]/70 hidden sm:inline">Certified Benchmark Calibration</span>
            </div>

            <div className="divide-y divide-[#C6A56B]/10">
              {/* Row 1: Horsepower */}
              <div className={`grid grid-cols-12 p-4 text-xs sm:text-sm items-center transition-colors ${
                highlightDifferences && hpA !== hpB ? 'bg-[#C6A56B]/5' : ''
              }`}>
                <div className="col-span-4 sm:col-span-3 text-[#A9A49A] font-medium uppercase tracking-wider text-[11px]">
                  Power Output
                </div>
                <div className="col-span-4 sm:col-span-4 font-serif text-[#F5F2EC] flex items-center gap-2">
                  <span className="text-base sm:text-lg">{carA.horsepower}</span>
                  {hpA > hpB && (
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-sans font-semibold uppercase bg-[#C6A56B]/20 text-[#C6A56B] border border-[#C6A56B]/40">
                      Higher
                    </span>
                  )}
                </div>
                <div className="col-span-4 sm:col-span-5 font-serif text-[#F5F2EC] flex items-center gap-2">
                  <span className="text-base sm:text-lg">{carB.horsepower}</span>
                  {hpB > hpA && (
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-sans font-semibold uppercase bg-[#C6A56B]/20 text-[#C6A56B] border border-[#C6A56B]/40">
                      Higher
                    </span>
                  )}
                </div>
              </div>

              {/* Row 2: Acceleration 0-60 */}
              <div className={`grid grid-cols-12 p-4 text-xs sm:text-sm items-center transition-colors ${
                highlightDifferences && accelA !== accelB ? 'bg-[#C6A56B]/5' : ''
              }`}>
                <div className="col-span-4 sm:col-span-3 text-[#A9A49A] font-medium uppercase tracking-wider text-[11px]">
                  0–60 MPH Sprint
                </div>
                <div className="col-span-4 sm:col-span-4 font-serif text-[#F5F2EC] flex items-center gap-2">
                  <span className="text-base sm:text-lg">{carA.acceleration}</span>
                  {accelA < accelB && (
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-sans font-semibold uppercase bg-[#C6A56B]/20 text-[#C6A56B] border border-[#C6A56B]/40">
                      Faster
                    </span>
                  )}
                </div>
                <div className="col-span-4 sm:col-span-5 font-serif text-[#F5F2EC] flex items-center gap-2">
                  <span className="text-base sm:text-lg">{carB.acceleration}</span>
                  {accelB < accelA && (
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-sans font-semibold uppercase bg-[#C6A56B]/20 text-[#C6A56B] border border-[#C6A56B]/40">
                      Faster
                    </span>
                  )}
                </div>
              </div>

              {/* Row 3: Top Speed */}
              <div className={`grid grid-cols-12 p-4 text-xs sm:text-sm items-center transition-colors ${
                highlightDifferences && speedA !== speedB ? 'bg-[#C6A56B]/5' : ''
              }`}>
                <div className="col-span-4 sm:col-span-3 text-[#A9A49A] font-medium uppercase tracking-wider text-[11px]">
                  V-Max Velocity
                </div>
                <div className="col-span-4 sm:col-span-4 font-serif text-[#F5F2EC] flex items-center gap-2">
                  <span className="text-base sm:text-lg">{carA.topSpeed}</span>
                  {speedA > speedB && (
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-sans font-semibold uppercase bg-[#C6A56B]/20 text-[#C6A56B] border border-[#C6A56B]/40">
                      Faster
                    </span>
                  )}
                </div>
                <div className="col-span-4 sm:col-span-5 font-serif text-[#F5F2EC] flex items-center gap-2">
                  <span className="text-base sm:text-lg">{carB.topSpeed}</span>
                  {speedB > speedA && (
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-sans font-semibold uppercase bg-[#C6A56B]/20 text-[#C6A56B] border border-[#C6A56B]/40">
                      Faster
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Section 2: Powertrain & Architecture */}
            <div className="bg-[#22211F] px-6 py-3 border-y border-[#C6A56B]/20 flex items-center justify-between">
              <span className="text-[11px] font-semibold tracking-[0.25em] uppercase text-[#C6A56B]">
                2. POWERTRAIN & CHASSIS
              </span>
            </div>

            <div className="divide-y divide-[#C6A56B]/10">
              {/* Powertrain */}
              <div className="grid grid-cols-12 p-4 text-xs sm:text-sm items-start">
                <div className="col-span-4 sm:col-span-3 text-[#A9A49A] font-medium uppercase tracking-wider text-[11px]">
                  Engine / Drive
                </div>
                <div className="col-span-4 sm:col-span-4 text-[#F5F2EC] pr-3 font-light">
                  {carA.powertrain}
                </div>
                <div className="col-span-4 sm:col-span-5 text-[#F5F2EC] font-light">
                  {carB.powertrain}
                </div>
              </div>

              {/* Transmission */}
              <div className="grid grid-cols-12 p-4 text-xs sm:text-sm items-center">
                <div className="col-span-4 sm:col-span-3 text-[#A9A49A] font-medium uppercase tracking-wider text-[11px]">
                  Transmission
                </div>
                <div className="col-span-4 sm:col-span-4 text-[#F5F2EC] pr-3 font-light">
                  {carA.transmission}
                </div>
                <div className="col-span-4 sm:col-span-5 text-[#F5F2EC] font-light">
                  {carB.transmission}
                </div>
              </div>

              {/* Weight */}
              <div className="grid grid-cols-12 p-4 text-xs sm:text-sm items-center">
                <div className="col-span-4 sm:col-span-3 text-[#A9A49A] font-medium uppercase tracking-wider text-[11px]">
                  Curb Weight
                </div>
                <div className="col-span-4 sm:col-span-4 text-[#F5F2EC] font-serif">
                  {carA.weight}
                </div>
                <div className="col-span-4 sm:col-span-5 text-[#F5F2EC] font-serif">
                  {carB.weight}
                </div>
              </div>

              {/* Efficiency */}
              <div className="grid grid-cols-12 p-4 text-xs sm:text-sm items-center">
                <div className="col-span-4 sm:col-span-3 text-[#A9A49A] font-medium uppercase tracking-wider text-[11px]">
                  Range / Economy
                </div>
                <div className="col-span-4 sm:col-span-4 text-[#F5F2EC] font-light">
                  {carA.rangeOrEconomy}
                </div>
                <div className="col-span-4 sm:col-span-5 text-[#F5F2EC] font-light">
                  {carB.rangeOrEconomy}
                </div>
              </div>
            </div>

            {/* Section 3: Proportions */}
            <div className="bg-[#22211F] px-6 py-3 border-y border-[#C6A56B]/20 flex items-center justify-between">
              <span className="text-[11px] font-semibold tracking-[0.25em] uppercase text-[#C6A56B]">
                3. DIMENSIONS & PROPORTIONS
              </span>
            </div>

            <div className="divide-y divide-[#C6A56B]/10">
              <div className="grid grid-cols-12 p-4 text-xs sm:text-sm items-center">
                <div className="col-span-4 sm:col-span-3 text-[#A9A49A] font-medium uppercase tracking-wider text-[11px]">
                  Overall Length
                </div>
                <div className="col-span-4 sm:col-span-4 text-[#F5F2EC]">
                  {carA.dimensions.length}
                </div>
                <div className="col-span-4 sm:col-span-5 text-[#F5F2EC]">
                  {carB.dimensions.length}
                </div>
              </div>

              <div className="grid grid-cols-12 p-4 text-xs sm:text-sm items-center">
                <div className="col-span-4 sm:col-span-3 text-[#A9A49A] font-medium uppercase tracking-wider text-[11px]">
                  Width (w/ Mirrors)
                </div>
                <div className="col-span-4 sm:col-span-4 text-[#F5F2EC]">
                  {carA.dimensions.width}
                </div>
                <div className="col-span-4 sm:col-span-5 text-[#F5F2EC]">
                  {carB.dimensions.width}
                </div>
              </div>

              <div className="grid grid-cols-12 p-4 text-xs sm:text-sm items-center">
                <div className="col-span-4 sm:col-span-3 text-[#A9A49A] font-medium uppercase tracking-wider text-[11px]">
                  Height
                </div>
                <div className="col-span-4 sm:col-span-4 text-[#F5F2EC]">
                  {carA.dimensions.height}
                </div>
                <div className="col-span-4 sm:col-span-5 text-[#F5F2EC]">
                  {carB.dimensions.height}
                </div>
              </div>
            </div>

            {/* Section 4: Bespoke Coachbuilt Features */}
            <div className="bg-[#22211F] px-6 py-3 border-y border-[#C6A56B]/20 flex items-center justify-between">
              <span className="text-[11px] font-semibold tracking-[0.25em] uppercase text-[#C6A56B]">
                4. SIGNATURE ATELIER AMENITIES
              </span>
            </div>

            <div className="grid grid-cols-12 p-5 text-xs gap-4">
              <div className="col-span-12 sm:col-span-3 text-[#A9A49A] font-medium uppercase tracking-wider text-[11px]">
                Key Highlights
              </div>
              <div className="col-span-6 sm:col-span-4 space-y-2">
                {carA.features.map((feat, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-[#F5F2EC]/90">
                    <Check className="w-3.5 h-3.5 text-[#C6A56B] shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
              <div className="col-span-6 sm:col-span-5 space-y-2">
                {carB.features.map((feat, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-[#F5F2EC]/90">
                    <Check className="w-3.5 h-3.5 text-[#C6A56B] shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Section 5: Available Exterior Palettes */}
            <div className="border-t border-[#C6A56B]/15 p-5 grid grid-cols-12 gap-4 text-xs bg-[#141312]">
              <div className="col-span-12 sm:col-span-3 text-[#A9A49A] font-medium uppercase tracking-wider text-[11px]">
                Bespoke Colors
              </div>
              <div className="col-span-6 sm:col-span-4 flex flex-wrap gap-2">
                {carA.colors.map((c) => (
                  <span
                    key={c.name}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#22211F] border border-[#C6A56B]/20 text-[11px] text-[#F5F2EC]"
                  >
                    <span className="w-2.5 h-2.5 rounded-full border border-white/20" style={{ backgroundColor: c.hex }} />
                    {c.name}
                  </span>
                ))}
              </div>
              <div className="col-span-6 sm:col-span-5 flex flex-wrap gap-2">
                {carB.colors.map((c) => (
                  <span
                    key={c.name}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#22211F] border border-[#C6A56B]/20 text-[11px] text-[#F5F2EC]"
                  >
                    <span className="w-2.5 h-2.5 rounded-full border border-white/20" style={{ backgroundColor: c.hex }} />
                    {c.name}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Modal Bottom Actions */}
        <div className="px-6 py-4 border-t border-[#C6A56B]/20 bg-[#161514] flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-[#A9A49A] text-center sm:text-left">
            Have questions about bespoke configurations or chassis allocations?
          </p>
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-5 py-2.5 text-xs font-medium uppercase tracking-wider text-[#A9A49A] hover:text-[#F5F2EC] bg-[#22211F] hover:bg-[#2c2a27] border border-[#C6A56B]/20 rounded-sm"
            >
              Close Comparison
            </button>
            <button
              onClick={() => {
                onBookConsultation(`${carA.name} vs ${carB.name}`);
                onClose();
              }}
              className="px-6 py-2.5 text-xs font-semibold uppercase tracking-wider bg-[#C6A56B] text-[#111110] hover:bg-[#d6b77e] transition-colors rounded-sm"
            >
              Book Comparative Test Drive
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
