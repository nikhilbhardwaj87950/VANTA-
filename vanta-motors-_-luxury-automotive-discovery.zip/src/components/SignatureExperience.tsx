import React from 'react';
import { ArrowRight, CheckCircle2, UserCheck, Shield, Sparkles } from 'lucide-react';
import { SafeImage } from './SafeImage';

interface SignatureExperienceProps {
  onDiscoverExperience: () => void;
}

export const SignatureExperience: React.FC<SignatureExperienceProps> = ({ onDiscoverExperience }) => {
  const benefits = [
    {
      title: 'Personalized vehicle consultation',
      description: 'Private 1-on-1 atelier sessions with our master configurators to tailor every stitch, veneer, and performance calibration.',
      icon: <UserCheck className="w-5 h-5 text-[#C6A56B]" />
    },
    {
      title: 'Curated automotive selection',
      description: 'Strictly limited build allocations ensuring uncompromising exclusivity, bespoke rarity, and preserved investment value.',
      icon: <Sparkles className="w-5 h-5 text-[#C6A56B]" />
    },
    {
      title: 'Dedicated customer assistance',
      description: 'A 24/7 private concierge liaison handling secure international transport, closed-track events, and lifetime bespoke care.',
      icon: <Shield className="w-5 h-5 text-[#C6A56B]" />
    }
  ];

  return (
    <section id="experience" className="py-24 md:py-32 bg-[#1B1A18] relative overflow-hidden border-t border-[#C6A56B]/20">
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Large Cinematic Luxury Automotive Visual */}
          <div className="lg:col-span-6 relative">
            <div className="relative aspect-[4/3] rounded-xl overflow-hidden border border-[#C6A56B]/30 shadow-2xl group">
              <SafeImage
                src="https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?auto=format&fit=crop&w=1600&q=85"
                alt="Vanta Motors Bespoke Interior Craftsmanship and Architectural Cockpit"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                fallbackTitle="THE VANTA EXPERIENCE"
                fallbackCategory="Signature Atelier"
              />
              {/* Subtle gold gradient edge */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#111110]/80 via-transparent to-transparent opacity-50" />
            </div>

            {/* Floating Luxury Detail Card */}
            <div className="absolute -bottom-6 -right-4 sm:right-6 bg-[#22211F]/95 backdrop-blur-md border border-[#C6A56B]/30 p-5 rounded-lg shadow-xl max-w-xs hidden sm:block">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-[#C6A56B] animate-pulse" />
                <span className="text-[10px] tracking-widest uppercase font-semibold text-[#C6A56B]">
                  Bespoke Commissioning
                </span>
              </div>
              <p className="text-xs text-[#F5F2EC] mt-2 font-light">
                Over 120 custom leather hide combinations & open-pore veneers handcrafted to your exact brief.
              </p>
            </div>
          </div>

          {/* Right Column: Editorial Narrative & Benefits */}
          <div className="lg:col-span-6 flex flex-col justify-center">
            {/* Eyebrow */}
            <div className="inline-flex items-center gap-3 mb-4">
              <span className="w-6 h-[1px] bg-[#C6A56B]" />
              <span className="text-[11px] font-semibold tracking-[0.28em] uppercase text-[#C6A56B]">
                THE VANTA EXPERIENCE
              </span>
            </div>

            {/* Heading */}
            <h2 className="font-serif text-3xl sm:text-5xl text-[#F5F2EC] font-normal leading-tight mb-6">
              More Than a Drive. <br />
              <span className="italic text-[#F5F2EC]/90">A Statement.</span>
            </h2>

            {/* Description */}
            <p className="text-sm sm:text-base text-[#A9A49A] font-light leading-relaxed mb-8">
              Experience a more personal approach to discovering exceptional automobiles. From your first enquiry to your next journey, every detail is thoughtfully considered.
            </p>

            {/* 3 Concrete Benefits */}
            <div className="space-y-6 mb-10">
              {benefits.map((benefit, i) => (
                <div key={i} className="flex items-start gap-4">
                  <div className="p-2 bg-[#22211F] border border-[#C6A56B]/25 rounded shrink-0 mt-0.5">
                    {benefit.icon}
                  </div>
                  <div>
                    <h3 className="text-sm sm:text-base font-serif text-[#F5F2EC] font-medium tracking-wide">
                      {benefit.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-[#A9A49A] font-light leading-relaxed mt-1">
                      {benefit.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* CTA */}
            <div>
              <button
                onClick={onDiscoverExperience}
                className="inline-flex items-center justify-center gap-3 px-8 py-4 text-xs font-semibold uppercase tracking-[0.22em] text-[#111110] bg-[#C6A56B] hover:bg-[#d6b77e] transition-all duration-300 rounded-sm cursor-pointer shadow-lg group"
              >
                <span>DISCOVER OUR EXPERIENCE</span>
                <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
