import React from 'react';
import { X, ShieldCheck } from 'lucide-react';

interface LegalModalProps {
  isOpen: boolean;
  title: string;
  content: string;
  onClose: () => void;
}

export const LegalModal: React.FC<LegalModalProps> = ({
  isOpen,
  title,
  content,
  onClose
}) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-lg bg-[#1B1A18] border border-[#C6A56B]/30 rounded-xl p-6 sm:p-8 shadow-2xl animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-[#A9A49A] hover:text-[#C6A56B] rounded-full hover:bg-[#22211F]"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-[#22211F] border border-[#C6A56B]/30 rounded text-[#C6A56B]">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] tracking-[0.25em] uppercase text-[#C6A56B] font-semibold">
              VANTA MOTORS LEGAL
            </span>
            <h3 className="font-serif text-xl sm:text-2xl text-[#F5F2EC]">
              {title}
            </h3>
          </div>
        </div>

        <div className="text-xs sm:text-sm text-[#A9A49A] leading-relaxed space-y-4 py-4 border-y border-[#C6A56B]/15">
          {content.split('\n\n').map((paragraph, idx) => (
            <p key={idx}>{paragraph.trim()}</p>
          ))}
        </div>

        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2.5 text-xs font-semibold uppercase tracking-wider bg-[#C6A56B] text-[#111110] hover:bg-[#d6b77e] transition-colors rounded-sm cursor-pointer"
          >
            I Understand
          </button>
        </div>
      </div>
    </div>
  );
};
