import React from 'react';

interface BrandLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showTagline?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  className = '',
  size = 'md',
  showTagline = true
}) => {
  const iconSize = size === 'sm' ? 'w-6 h-6' : size === 'lg' ? 'w-10 h-10' : 'w-8 h-8';
  const titleSize = size === 'sm' ? 'text-base' : size === 'lg' ? 'text-2xl' : 'text-lg';

  return (
    <a href="#" className={`group inline-flex items-center gap-3 transition-opacity hover:opacity-90 ${className}`}>
      {/* Custom Geometric Emblem: Faceted architectural luxury chevron shield */}
      <div className={`relative ${iconSize} flex-shrink-0 flex items-center justify-center`}>
        <svg
          viewBox="0 0 40 40"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full text-[#C6A56B] transition-transform duration-500 group-hover:scale-105"
        >
          {/* Outer diamond contour */}
          <polygon
            points="20,2 38,20 20,38 2,20"
            stroke="currentColor"
            strokeWidth="1.5"
            fill="rgba(198, 165, 107, 0.08)"
          />
          {/* Inner faceted V for Vanta */}
          <path
            d="M12 14L20 28L28 14"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* Horizontal aerodynamic baseline */}
          <line
            x1="15"
            y1="21"
            x2="25"
            y2="21"
            stroke="#F5F2EC"
            strokeWidth="1.2"
          />
          {/* Apex jewel star point */}
          <circle cx="20" cy="8" r="1.2" fill="#F5F2EC" />
        </svg>
      </div>

      <div className="flex flex-col">
        <span className={`font-serif tracking-[0.28em] font-semibold text-[#F5F2EC] uppercase ${titleSize} leading-none`}>
          VANTA
        </span>
        {showTagline && (
          <span className="text-[9px] tracking-[0.45em] text-[#C6A56B] uppercase font-sans font-medium mt-1 leading-none">
            MOTORS
          </span>
        )}
      </div>
    </a>
  );
};
