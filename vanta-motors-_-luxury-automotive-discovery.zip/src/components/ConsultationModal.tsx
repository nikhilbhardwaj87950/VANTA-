import React, { useState } from 'react';
import { X, Calendar, Clock, MapPin, User, Mail, Phone, CheckCircle2 } from 'lucide-react';
import { VEHICLES } from '../data/vehicles';

interface ConsultationModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultVehicle?: string;
}

export const ConsultationModal: React.FC<ConsultationModalProps> = ({
  isOpen,
  onClose,
  defaultVehicle
}) => {
  const [selectedVehicle, setSelectedVehicle] = useState(defaultVehicle || VEHICLES[0].name);
  const [experienceType, setExperienceType] = useState<'showroom' | 'testdrive' | 'virtual'>('showroom');
  const [location, setLocation] = useState('London Mayfair Atelier');
  const [date, setDate] = useState('');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  const handleReset = () => {
    setIsSubmitted(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div
        className="relative w-full max-w-2xl bg-[#1B1A18] border border-[#C6A56B]/30 rounded-xl overflow-hidden shadow-2xl p-6 sm:p-8 animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-[#A9A49A] hover:text-[#C6A56B] rounded-full hover:bg-[#22211F]"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {isSubmitted ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 rounded-full bg-[#C6A56B]/10 border border-[#C6A56B] flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 className="w-8 h-8 text-[#C6A56B]" />
            </div>
            <h3 className="font-serif text-2xl sm:text-3xl text-[#F5F2EC] mb-3">
              Consultation Reserved
            </h3>
            <p className="text-sm text-[#A9A49A] max-w-md mx-auto mb-6">
              Thank you, <span className="text-[#F5F2EC] font-medium">{fullName}</span>. Your private consultation for the <span className="text-[#C6A56B]">{selectedVehicle}</span> has been logged. Our Client Director will contact you within 4 business hours to finalize arrangements.
            </p>
            <div className="p-4 bg-[#22211F] border border-[#C6A56B]/20 rounded-md text-xs text-[#A9A49A] mb-8 text-left max-w-md mx-auto space-y-1.5">
              <p><strong className="text-[#F5F2EC]">Venue:</strong> {location}</p>
              <p><strong className="text-[#F5F2EC]">Format:</strong> {experienceType === 'showroom' ? 'Private Atelier Session' : experienceType === 'testdrive' ? 'Closed-Circuit Dynamic Drive' : 'Private Digital Configurator'}</p>
              {date && <p><strong className="text-[#F5F2EC]">Preferred Date:</strong> {date}</p>}
            </div>
            <button
              onClick={handleReset}
              className="px-8 py-3 text-xs font-semibold uppercase tracking-[0.2em] bg-[#C6A56B] text-[#111110] hover:bg-[#d6b77e] transition-colors rounded-sm"
            >
              Return to Discovery
            </button>
          </div>
        ) : (
          <div>
            <div className="mb-6">
              <span className="text-[10px] tracking-[0.25em] uppercase text-[#C6A56B] font-semibold">
                PRIVATE CLIENT SERVICES
              </span>
              <h3 className="font-serif text-2xl sm:text-3xl text-[#F5F2EC] mt-1">
                Schedule Your VIP Experience
              </h3>
              <p className="text-xs sm:text-sm text-[#A9A49A] mt-1.5">
                Reserve a bespoke private consultation, dynamic circuit drive, or commission consultation with our master curators.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Experience Format Selector */}
              <div>
                <label className="text-[10px] uppercase tracking-wider text-[#A9A49A] block mb-2 font-medium">
                  Experience Format
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'showroom', label: 'Private Atelier' },
                    { id: 'testdrive', label: 'Circuit Drive' },
                    { id: 'virtual', label: 'Digital Session' },
                  ].map((item) => (
                    <button
                      type="button"
                      key={item.id}
                      onClick={() => setExperienceType(item.id as any)}
                      className={`py-2 px-3 text-xs font-medium uppercase tracking-wider rounded border text-center transition-all ${
                        experienceType === item.id
                          ? 'border-[#C6A56B] bg-[#22211F] text-[#C6A56B]'
                          : 'border-[#C6A56B]/15 bg-[#161514] text-[#A9A49A] hover:border-[#C6A56B]/30'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Vehicle Selection */}
              <div>
                <label className="text-[10px] uppercase tracking-wider text-[#A9A49A] block mb-1.5 font-medium">
                  Preferred Model of Interest
                </label>
                <select
                  value={selectedVehicle}
                  onChange={(e) => setSelectedVehicle(e.target.value)}
                  className="w-full bg-[#22211F] border border-[#C6A56B]/20 text-[#F5F2EC] px-3.5 py-2.5 rounded text-xs focus:outline-none focus:border-[#C6A56B]"
                >
                  {VEHICLES.map((car) => (
                    <option key={car.id} value={car.name} className="bg-[#1B1A18] text-[#F5F2EC]">
                      {car.name} — {car.category}
                    </option>
                  ))}
                </select>
              </div>

              {/* Showroom Location & Date */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] uppercase tracking-wider text-[#A9A49A] block mb-1.5 font-medium">
                    Atelier Location
                  </label>
                  <select
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full bg-[#22211F] border border-[#C6A56B]/20 text-[#F5F2EC] px-3.5 py-2.5 rounded text-xs focus:outline-none focus:border-[#C6A56B]"
                  >
                    <option value="London Mayfair Atelier">London Mayfair Atelier</option>
                    <option value="Geneva Private Lounge">Geneva Private Lounge</option>
                    <option value="Monaco Port Hercule Pavilion">Monaco Port Hercule Pavilion</option>
                    <option value="New York Madison Avenue Studio">New York Madison Avenue Studio</option>
                    <option value="Tokyo Ginza Atelier">Tokyo Ginza Atelier</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] uppercase tracking-wider text-[#A9A49A] block mb-1.5 font-medium">
                    Requested Date
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-[#22211F] border border-[#C6A56B]/20 text-[#F5F2EC] px-3.5 py-2.5 rounded text-xs focus:outline-none focus:border-[#C6A56B]"
                  />
                </div>
              </div>

              {/* Client Credentials */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                <div>
                  <label className="text-[10px] uppercase tracking-wider text-[#A9A49A] block mb-1 font-medium">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Lord Sterling"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full bg-[#22211F] border border-[#C6A56B]/20 text-[#F5F2EC] px-3 py-2 rounded text-xs focus:outline-none focus:border-[#C6A56B]"
                  />
                </div>

                <div>
                  <label className="text-[10px] uppercase tracking-wider text-[#A9A49A] block mb-1 font-medium">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="client@prestige.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-[#22211F] border border-[#C6A56B]/20 text-[#F5F2EC] px-3 py-2 rounded text-xs focus:outline-none focus:border-[#C6A56B]"
                  />
                </div>

                <div>
                  <label className="text-[10px] uppercase tracking-wider text-[#A9A49A] block mb-1 font-medium">
                    Telephone *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="+44 20 7946 0912"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-[#22211F] border border-[#C6A56B]/20 text-[#F5F2EC] px-3 py-2 rounded text-xs focus:outline-none focus:border-[#C6A56B]"
                  />
                </div>
              </div>

              {/* Disclaimer */}
              <p className="text-[10px] text-[#A9A49A]/70 pt-1">
                All inquiries are treated with strict confidentiality. A dedicated client advisor will confirm availability according to your preference.
              </p>

              {/* Submit CTA */}
              <div className="pt-3 border-t border-[#C6A56B]/20 flex justify-end">
                <button
                  type="submit"
                  className="px-6 py-3 text-xs font-semibold uppercase tracking-[0.2em] bg-[#C6A56B] text-[#111110] hover:bg-[#d6b77e] transition-colors rounded-sm cursor-pointer shadow-lg"
                >
                  Confirm Reservation Request
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
