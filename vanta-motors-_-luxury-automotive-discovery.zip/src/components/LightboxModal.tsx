import React, { useEffect } from 'react';
import { X, ChevronLeft, ChevronRight, Maximize2 } from 'lucide-react';
import { GalleryItem } from '../data/vehicles';
import { SafeImage } from './SafeImage';

interface LightboxModalProps {
  item: GalleryItem | null;
  items: GalleryItem[];
  onClose: () => void;
  onNavigate: (direction: 'next' | 'prev') => void;
}

export const LightboxModal: React.FC<LightboxModalProps> = ({
  item,
  items,
  onClose,
  onNavigate
}) => {
  useEffect(() => {
    if (!item) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') onNavigate('next');
      if (e.key === 'ArrowLeft') onNavigate('prev');
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [item, onClose, onNavigate]);

  if (!item) return null;

  const currentIndex = items.findIndex((i) => i.id === item.id);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-xl p-4 sm:p-8"
      onClick={onClose}
    >
      {/* Top Bar Controls */}
      <div className="absolute top-6 left-6 right-6 flex items-center justify-between z-20" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-3">
          <span className="text-[11px] font-semibold tracking-[0.25em] uppercase text-[#C6A56B]">
            {item.category}
          </span>
          <span className="text-[#A9A49A]/40">·</span>
          <span className="text-xs text-[#A9A49A]">
            {currentIndex + 1} of {items.length}
          </span>
        </div>

        <button
          onClick={onClose}
          className="p-2.5 rounded-full bg-[#1B1A18]/80 text-[#F5F2EC] hover:text-[#C6A56B] border border-[#C6A56B]/30 hover:border-[#C6A56B] transition-all"
          aria-label="Close lightbox"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Prev / Next buttons */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          onNavigate('prev');
        }}
        className="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 z-20 p-3 rounded-full bg-[#1B1A18]/80 text-[#F5F2EC] hover:text-[#C6A56B] border border-[#C6A56B]/25 hover:border-[#C6A56B] transition-all"
        aria-label="Previous photo"
      >
        <ChevronLeft className="w-6 h-6" />
      </button>

      <button
        onClick={(e) => {
          e.stopPropagation();
          onNavigate('next');
        }}
        className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 z-20 p-3 rounded-full bg-[#1B1A18]/80 text-[#F5F2EC] hover:text-[#C6A56B] border border-[#C6A56B]/25 hover:border-[#C6A56B] transition-all"
        aria-label="Next photo"
      >
        <ChevronRight className="w-6 h-6" />
      </button>

      {/* Main Image Container */}
      <div
        className="relative max-w-5xl max-h-[80vh] w-full flex flex-col items-center justify-center"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative overflow-hidden rounded-lg border border-[#C6A56B]/20 shadow-2xl bg-[#111110]">
          <SafeImage
            src={item.imageUrl}
            alt={item.title}
            className="max-h-[70vh] w-auto object-contain mx-auto"
            fallbackTitle={item.title}
            fallbackCategory={item.category}
          />
        </div>

        {/* Caption */}
        <div className="mt-4 text-center max-w-xl">
          <h4 className="font-serif text-xl sm:text-2xl text-[#F5F2EC] font-normal">
            {item.title}
          </h4>
          <p className="text-xs sm:text-sm text-[#A9A49A] mt-1 font-light">
            {item.subtitle}
          </p>
        </div>
      </div>
    </div>
  );
};
