import React, { useState, useRef } from 'react';
import { Mic, Square, Loader2, Volume2, AlertCircle } from 'lucide-react';

interface VoiceTranscriberProps {
  onTranscriptionComplete: (transcript: string) => void;
  placeholderPrompt?: string;
  className?: string;
  buttonLabel?: string;
}

export const VoiceTranscriber: React.FC<VoiceTranscriberProps> = ({
  onTranscriptionComplete,
  placeholderPrompt,
  className = '',
  buttonLabel = 'Voice Input'
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [recordingSeconds, setRecordingSeconds] = useState(0);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);

  const startRecording = async () => {
    setErrorMessage(null);
    audioChunksRef.current = [];
    setRecordingSeconds(0);

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Microphone access is not supported in this browser.');
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        // Stop all audio tracks
        stream.getTracks().forEach((track) => track.stop());

        const audioBlob = new Blob(audioChunksRef.current, {
          type: mediaRecorder.mimeType || 'audio/webm',
        });

        await handleTranscribeAudio(audioBlob, mediaRecorder.mimeType || 'audio/webm');
      };

      mediaRecorder.start();
      setIsRecording(true);

      // Start timer
      timerRef.current = window.setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      console.error('Microphone error:', err);
      setErrorMessage(
        err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError'
          ? 'Microphone permission denied. Please allow microphone access in your browser settings.'
          : err.message || 'Could not access microphone.'
      );
    }
  };

  const stopRecording = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    setIsRecording(false);
  };

  const blobToBase64 = (blob: Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = (reader.result as string).split(',')[1];
        resolve(base64String);
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  };

  const handleTranscribeAudio = async (blob: Blob, mimeType: string) => {
    setIsTranscribing(true);
    setErrorMessage(null);

    try {
      const base64Audio = await blobToBase64(blob);

      const response = await fetch('/api/transcribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          audio: base64Audio,
          mimeType,
          prompt: placeholderPrompt || 'Transcribe this voice audio accurately for a bespoke luxury automotive inquiry.',
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Server failed to transcribe audio');
      }

      if (data.transcript) {
        onTranscriptionComplete(data.transcript);
      } else {
        setErrorMessage('No distinct speech was detected. Please try speaking clearly into your microphone.');
      }
    } catch (err: any) {
      console.error('Transcription API failure:', err);
      setErrorMessage(err.message || 'Failed to transcribe audio with Gemini 3.5 Transcribe.');
    } finally {
      setIsTranscribing(false);
    }
  };

  return (
    <div className={`relative inline-flex items-center ${className}`}>
      {isRecording ? (
        <div className="flex items-center gap-3 bg-[#22211F] border border-red-500/50 px-3 py-1.5 rounded text-xs animate-pulse">
          <div className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
          <span className="text-red-400 font-mono text-[11px]">
            {Math.floor(recordingSeconds / 60)}:{(recordingSeconds % 60).toString().padStart(2, '0')}
          </span>
          <span className="text-[#F5F2EC] text-[11px] hidden sm:inline">Listening...</span>
          <button
            type="button"
            onClick={stopRecording}
            className="p-1 rounded bg-red-500/20 text-red-300 hover:bg-red-500/40 ml-1 transition-colors"
            title="Stop and Transcribe"
          >
            <Square className="w-3.5 h-3.5 fill-current" />
          </button>
        </div>
      ) : isTranscribing ? (
        <div className="flex items-center gap-2 bg-[#22211F] border border-[#C6A56B]/40 px-3 py-1.5 rounded text-xs text-[#C6A56B]">
          <Loader2 className="w-3.5 h-3.5 animate-spin" />
          <span className="text-[11px] tracking-wide">Transcribing with Gemini 3.5...</span>
        </div>
      ) : (
        <button
          type="button"
          onClick={startRecording}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs text-[#C6A56B] hover:text-[#111110] bg-[#22211F] hover:bg-[#C6A56B] border border-[#C6A56B]/30 hover:border-[#C6A56B] rounded transition-all duration-200 cursor-pointer"
          title="Dictate with microphone (powered by gemini-3.5-transcribe)"
        >
          <Mic className="w-3.5 h-3.5" />
          <span className="text-[11px] tracking-wider uppercase font-medium">{buttonLabel}</span>
        </button>
      )}

      {errorMessage && (
        <div className="absolute top-full left-0 mt-2 z-30 p-2 bg-[#1B1A18] border border-red-500/40 rounded shadow-xl text-[11px] text-red-300 max-w-xs flex items-start gap-1.5">
          <AlertCircle className="w-3.5 h-3.5 text-red-400 shrink-0 mt-0.5" />
          <div>
            <span>{errorMessage}</span>
            <button
              type="button"
              onClick={() => setErrorMessage(null)}
              className="ml-2 text-white/50 hover:text-white underline"
            >
              dismiss
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
