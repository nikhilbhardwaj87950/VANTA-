import React, { useState, useEffect } from 'react';
import { Search, Menu, X, ArrowRight, ArrowLeftRight } from 'lucide-react';
import { BrandLogo } from './BrandLogo';

interface NavbarProps {
  onOpenSearch: () => void;
  onExploreClick: () => void;
  onOpenCompare: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenSearch, onExploreClick, onOpenCompare }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Home', href: '#hero' },
    { label: 'Collection', href: '#collection' },
    { label: 'Our Story', href: '#story' },
    { label: 'Experience', href: '#experience' },
    { label: 'Gallery', href: '#gallery' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-500 ${
          isScrolled
            ? 'bg-[#111110]/90 backdrop-blur-md border-b border-[#C6A56B]/20 py-3 shadow-xl'
            : 'bg-gradient-to-b from-[#111110]/80 via-[#111110]/30 to-transparent border-b border-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 md:px-10 flex items-center justify-between gap-8">
          {/* Zone 1: Brand Wordmark + Emblem */}
          <div className="flex-shrink-0">
            <BrandLogo />
          </div>

          {/* Zone 2: Editorial Navigation Links */}
          <nav className="hidden lg:flex items-center gap-8 xl:gap-10">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="relative py-1 text-xs uppercase tracking-[0.2em] font-medium text-[#A9A49A] hover:text-[#F5F2EC] transition-colors group"
              >
                <span>{link.label}</span>
                {/* Smooth hover underline animation */}
                <span className="absolute bottom-0 left-0 w-0 h-[1.5px] bg-[#C6A56B] transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </nav>

          {/* Zone 3: Compare + Search Icon + CTA Button */}
          <div className="hidden sm:flex items-center gap-3 xl:gap-4">
            <button
              onClick={onOpenCompare}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs uppercase tracking-wider font-medium text-[#A9A49A] hover:text-[#C6A56B] bg-[#1B1A18]/60 hover:bg-[#22211F] rounded border border-[#C6A56B]/20 transition-all cursor-pointer"
              title="Compare Vehicles Side-by-Side"
            >
              <ArrowLeftRight className="w-3.5 h-3.5 text-[#C6A56B]" />
              <span>Compare</span>
            </button>

            <button
              onClick={onOpenSearch}
              className="p-2 text-[#A9A49A] hover:text-[#C6A56B] transition-colors rounded-full hover:bg-[#1B1A18]/60 border border-transparent hover:border-[#C6A56B]/20"
              aria-label="Search Collection"
            >
              <Search className="w-4 h-4" />
            </button>

            <button
              onClick={onExploreClick}
              className="relative inline-flex items-center justify-center px-5 py-2.5 text-xs font-semibold uppercase tracking-[0.18em] text-[#111110] bg-[#C6A56B] hover:bg-[#d6b77e] transition-all duration-300 shadow-md hover:shadow-[#C6A56B]/20 rounded-sm overflow-hidden group cursor-pointer"
            >
              <span className="relative z-10 flex items-center gap-1.5">
                Explore Collection
                <ArrowRight className="w-3.5 h-3.5 transition-transform duration-300 group-hover:translate-x-1" />
              </span>
            </button>
          </div>

          {/* Mobile Right Controls: Search + Hamburger */}
          <div className="flex items-center gap-2 lg:hidden">
            <button
              onClick={onOpenSearch}
              className="p-2 text-[#A9A49A] hover:text-[#C6A56B] transition-colors"
              aria-label="Search"
            >
              <Search className="w-5 h-5" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-[#F5F2EC] hover:text-[#C6A56B] transition-colors"
              aria-label="Toggle navigation menu"
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/80 backdrop-blur-lg lg:hidden"
          onClick={() => setMobileMenuOpen(false)}
        >
          <div
            className="absolute top-0 right-0 w-4/5 max-w-sm h-full bg-[#1B1A18] border-l border-[#C6A56B]/20 p-8 flex flex-col justify-between"
            onClick={(e) => e.stopPropagation()}
          >
            <div>
              <div className="flex items-center justify-between pb-6 border-b border-[#C6A56B]/20">
                <BrandLogo size="sm" />
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-2 text-[#A9A49A] hover:text-[#F5F2EC]"
                  aria-label="Close menu"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex flex-col gap-6 mt-8">
                {navLinks.map((link) => (
                  <a
                    key={link.label}
                    href={link.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className="text-sm font-medium tracking-[0.2em] uppercase text-[#F5F2EC] hover:text-[#C6A56B] transition-colors"
                  >
                    {link.label}
                  </a>
                ))}
              </div>
            </div>

            <div className="pt-6 border-t border-[#C6A56B]/20 flex flex-col gap-3">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenCompare();
                }}
                className="w-full py-2.5 text-xs font-medium uppercase tracking-[0.16em] text-[#F5F2EC] bg-[#22211F] hover:bg-[#2a2926] border border-[#C6A56B]/30 transition-colors text-center rounded-sm flex items-center justify-center gap-2"
              >
                <ArrowLeftRight className="w-3.5 h-3.5 text-[#C6A56B]" />
                Compare Models
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onExploreClick();
                }}
                className="w-full py-3 text-xs font-semibold uppercase tracking-[0.18em] text-[#111110] bg-[#C6A56B] hover:bg-[#d6b77e] transition-colors text-center rounded-sm"
              >
                Explore Collection
              </button>
              <p className="text-[10px] tracking-widest text-center text-[#A9A49A] uppercase mt-2">
                Bespoke Atelier · Private Client Service
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
