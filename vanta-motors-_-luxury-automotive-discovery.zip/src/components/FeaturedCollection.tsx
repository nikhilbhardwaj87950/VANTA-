import React, { useState } from 'react';
import { ArrowRight, Zap, Gauge, Compass, ArrowLeftRight } from 'lucide-react';
import { VEHICLES, Vehicle } from '../data/vehicles';
import { SafeImage } from './SafeImage';

interface FeaturedCollectionProps {
  onSelectVehicle: (vehicle: Vehicle) => void;
  onOpenCompare?: (vehicleId?: string) => void;
}

export const FeaturedCollection: React.FC<FeaturedCollectionProps> = ({
  onSelectVehicle,
  onOpenCompare
}) => {
  const [showAll, setShowAll] = useState(false);

  const displayedVehicles = showAll ? VEHICLES : VEHICLES.filter((v) => v.featured);

  return (
    <section id="collection" className="py-24 md:py-32 bg-[#111110] relative">
      {/* Background subtle ambiance */}
      <div className="absolute top-1/2 left-0 w-72 h-72 bg-[#C6A56B]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-3 mb-3">
              <span className="w-6 h-[1px] bg-[#C6A56B]" />
              <span className="text-[11px] font-semibold tracking-[0.28em] uppercase text-[#C6A56B]">
                THE VANTA FLEET
              </span>
            </div>
            <h2 className="font-serif text-3xl sm:text-5xl text-[#F5F2EC] font-normal leading-tight">
              Exceptional Machines. <br className="hidden sm:block" />
              <span className="italic text-[#F5F2EC]/90">Timeless Desires.</span>
            </h2>
            <p className="text-sm sm:text-base text-[#A9A49A] mt-4 font-light">
              Explore a carefully curated collection of extraordinary automobiles.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 self-start md:self-end">
            {onOpenCompare && (
              <button
                onClick={() => onOpenCompare()}
                className="inline-flex items-center gap-2 px-5 py-3 text-xs font-semibold uppercase tracking-[0.18em] text-[#F5F2EC] hover:text-[#C6A56B] bg-[#1B1A18] hover:bg-[#22211F] border border-[#C6A56B]/30 hover:border-[#C6A56B] transition-all duration-300 rounded-sm cursor-pointer"
              >
                <ArrowLeftRight className="w-3.5 h-3.5 text-[#C6A56B]" />
                <span>COMPARE MODELS</span>
              </button>
            )}

            <button
              onClick={() => setShowAll(!showAll)}
              className="inline-flex items-center gap-2 px-6 py-3 text-xs font-semibold uppercase tracking-[0.2em] text-[#C6A56B] hover:text-[#111110] hover:bg-[#C6A56B] border border-[#C6A56B]/40 transition-all duration-300 rounded-sm cursor-pointer"
            >
              <span>{showAll ? 'SHOW FEATURED TRIO' : 'VIEW ALL COLLECTION'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Vehicle Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {displayedVehicles.map((car) => (
            <div
              key={car.id}
              className="group flex flex-col justify-between bg-[#22211F] border border-[#C6A56B]/20 rounded-xl overflow-hidden hover:border-[#C6A56B]/60 transition-all duration-500 shadow-xl hover:shadow-2xl hover:shadow-[#C6A56B]/10 hover:-translate-y-1"
            >
              {/* Card Top: Image Showcase */}
              <div className="relative aspect-[16/10] overflow-hidden bg-[#161514]">
                <div className="absolute inset-0 z-10 bg-gradient-to-t from-[#22211F] via-transparent to-transparent opacity-60" />
                
                {/* Category Pill / Tag */}
                <div className="absolute top-4 left-4 z-20">
                  <span className="text-[10px] tracking-[0.25em] uppercase font-semibold text-[#111110] bg-[#C6A56B] px-3 py-1 rounded-sm shadow-md">
                    {car.category}
                  </span>
                </div>

                {/* Starting Price Tag */}
                <div className="absolute top-4 right-4 z-20">
                  <span className="text-[11px] tracking-wider text-[#F5F2EC] bg-[#111110]/80 backdrop-blur-sm border border-[#C6A56B]/20 px-2.5 py-1 rounded-sm">
                    {car.startingPrice}
                  </span>
                </div>

                <div className="w-full h-full transform transition-transform duration-700 ease-out group-hover:scale-108">
                  <SafeImage
                    src={car.imageUrl}
                    alt={car.name}
                    className="w-full h-full object-cover"
                    fallbackTitle={car.name}
                    fallbackCategory={car.category}
                  />
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 sm:p-7 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-serif text-2xl text-[#F5F2EC] mb-2 group-hover:text-[#C6A56B] transition-colors">
                    {car.name}
                  </h3>
                  <p className="text-xs sm:text-sm text-[#A9A49A] font-light leading-relaxed mb-6 line-clamp-2">
                    {car.description}
                  </p>

                  {/* Specification Highlights */}
                  <div className="grid grid-cols-3 gap-2 py-4 border-y border-[#C6A56B]/15 mb-6 text-center">
                    <div>
                      <p className="text-sm sm:text-base font-serif text-[#F5F2EC] font-medium">{car.horsepower}</p>
                      <p className="text-[9px] uppercase tracking-wider text-[#A9A49A] mt-0.5">Horsepower</p>
                    </div>
                    <div className="border-x border-[#C6A56B]/15">
                      <p className="text-sm sm:text-base font-serif text-[#F5F2EC] font-medium">{car.acceleration}</p>
                      <p className="text-[9px] uppercase tracking-wider text-[#A9A49A] mt-0.5">0–60 MPH</p>
                    </div>
                    <div>
                      <p className="text-sm sm:text-base font-serif text-[#F5F2EC] font-medium">{car.topSpeed}</p>
                      <p className="text-[9px] uppercase tracking-wider text-[#A9A49A] mt-0.5">Top Speed</p>
                    </div>
                  </div>
                </div>

                {/* Card CTAs */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onSelectVehicle(car)}
                    className="flex-1 inline-flex items-center justify-center gap-2 py-3 px-3 text-xs font-semibold uppercase tracking-[0.16em] text-[#F5F2EC] hover:text-[#111110] bg-[#1B1A18] hover:bg-[#C6A56B] border border-[#C6A56B]/30 hover:border-[#C6A56B] transition-all duration-300 rounded-sm cursor-pointer"
                  >
                    <span>Discover Vehicle</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  {onOpenCompare && (
                    <button
                      onClick={() => onOpenCompare(car.id)}
                      className="p-3 text-[#A9A49A] hover:text-[#C6A56B] bg-[#1B1A18] hover:bg-[#22211F] border border-[#C6A56B]/30 hover:border-[#C6A56B] rounded-sm transition-colors cursor-pointer"
                      title={`Compare ${car.name} with another model`}
                      aria-label={`Compare ${car.name}`}
                    >
                      <ArrowLeftRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
