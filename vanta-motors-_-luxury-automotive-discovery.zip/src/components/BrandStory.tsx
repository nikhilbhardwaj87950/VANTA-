import React from 'react';
import { SafeImage } from './SafeImage';

export const BrandStory: React.FC = () => {
  return (
    <section id="story" className="py-24 md:py-32 bg-[#111110] relative">
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        {/* Section Eyebrow & Title */}
        <div className="text-center max-w-3xl mx-auto mb-20">
          <div className="inline-flex items-center justify-center gap-3 mb-4">
            <span className="w-8 h-[1px] bg-[#C6A56B]" />
            <span className="text-[11px] font-semibold tracking-[0.3em] uppercase text-[#C6A56B]">
              THE HERITAGE OF CRAFTSMANSHIP
            </span>
            <span className="w-8 h-[1px] bg-[#C6A56B]" />
          </div>
          <h2 className="font-serif text-3xl sm:text-5xl lg:text-6xl text-[#F5F2EC] font-normal tracking-tight">
            Driven by Passion. <br />
            <span className="italic text-[#F5F2EC]/90">Defined by Precision.</span>
          </h2>
          <div className="w-16 h-[1.5px] bg-[#C6A56B] mx-auto mt-6" />
        </div>

        {/* Editorial Narrative Split 1: Philosophy & Atelier Craft */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center mb-24">
          <div className="lg:col-span-5 order-2 lg:order-1">
            <span className="text-[10px] tracking-[0.25em] uppercase text-[#C6A56B] font-semibold">
              CHAPTER I · THE ATELIER PHILOSOPHY
            </span>
            <h3 className="font-serif text-2xl sm:text-3xl text-[#F5F2EC] mt-2 mb-6 font-normal">
              Where Engineering Meets Haute Couture
            </h3>
            <p className="text-sm sm:text-base text-[#A9A49A] font-light leading-relaxed mb-6">
              Vanta Motors was established with a singular conviction: that the modern automobile should not merely be an instrument of transit, but a work of kinetic architecture. Every chassis is conceived as a bespoke sculpture—balancing ruthless aerodynamic computational flow with the timeless warmth of hand-worked natural materials.
            </p>
            <p className="text-sm text-[#A9A49A] font-light leading-relaxed">
              In an era dominated by rapid mass manufacturing, our master artisans dedicate up to 450 hours of hand assembly to each individual vehicle. From the millimetric alignment of dry carbon weave to the twin-needle stitching on sustainably sourced hides, perfection is our baseline.
            </p>

            <div className="mt-8 pt-6 border-t border-[#C6A56B]/20 grid grid-cols-2 gap-6">
              <div>
                <p className="font-serif text-2xl text-[#C6A56B]">450+</p>
                <p className="text-[10px] tracking-widest text-[#A9A49A] uppercase mt-1">Hours of Hand Craft</p>
              </div>
              <div>
                <p className="font-serif text-2xl text-[#C6A56B]">1 of 1</p>
                <p className="text-[10px] tracking-widest text-[#A9A49A] uppercase mt-1">Bespoke Specifications</p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 order-1 lg:order-2">
            <div className="relative aspect-[16/10] rounded-xl overflow-hidden border border-[#C6A56B]/25 shadow-2xl">
              <SafeImage
                src="https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1600&q=85"
                alt="Vanta Motors Design Studio & Clay Modeling Facility"
                className="w-full h-full object-cover"
                fallbackTitle="VANTA ATELIER"
                fallbackCategory="Design & Engineering"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#111110]/80 via-transparent to-transparent" />
              <div className="absolute bottom-4 left-6 right-6 flex items-center justify-between text-xs text-[#F5F2EC]/80">
                <span className="font-serif italic">The Aerodynamic Clay Studio</span>
                <span className="tracking-widest uppercase text-[10px] text-[#C6A56B]">Turin, Italy</span>
              </div>
            </div>
          </div>
        </div>

        {/* Editorial Light Accent Breakout Card: The Commissioning Experience */}
        <div className="bg-[#EAE5DC] text-[#25231F] rounded-xl p-8 sm:p-12 lg:p-16 mb-24 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#C6A56B]/15 rounded-full blur-3xl pointer-events-none" />
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
            <div className="lg:col-span-7">
              <span className="text-[11px] font-semibold tracking-[0.28em] uppercase text-[#9C7B4F]">
                THE BESPOKE COMMISSION PROGRAM
              </span>
              <h3 className="font-serif text-3xl sm:text-4xl text-[#25231F] mt-2 mb-4 font-normal">
                An Intimate Dialogue Between Collector and Creator
              </h3>
              <p className="text-sm sm:text-base text-[#25231F]/80 leading-relaxed font-light">
                No two Vanta automobiles are ever created identical. Through our Private Client Commissioning program, you collaborate directly with our lead automotive designers. Choose from rare anodized titanium finishes, monogrammed upholstery embroideries, or commission a proprietary paint formulation reserved exclusively for your vehicle.
              </p>
            </div>

            <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-[#DFD9CD] p-5 rounded border border-[#C6A56B]/40">
                <p className="font-serif text-lg font-medium text-[#25231F]">Acoustic Tuning</p>
                <p className="text-xs text-[#25231F]/70 mt-1 font-light">Exhaust harmonics tuned specifically to match the owner's pitch preference.</p>
              </div>
              <div className="bg-[#DFD9CD] p-5 rounded border border-[#C6A56B]/40">
                <p className="font-serif text-lg font-medium text-[#25231F]">Heirloom Materials</p>
                <p className="text-xs text-[#25231F]/70 mt-1 font-light">Sustainably harvested open-pore burr walnut, olive ash, and matte carbon.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Editorial Narrative Split 2: Precision Engineering */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          <div className="lg:col-span-7">
            <div className="relative aspect-[16/10] rounded-xl overflow-hidden border border-[#C6A56B]/25 shadow-2xl">
              <SafeImage
                src="https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=1600&q=85"
                alt="Precision Powertrain Calibration and Dynamic Testing"
                className="w-full h-full object-cover"
                fallbackTitle="PRECISION DYNAMICS"
                fallbackCategory="Track Validation"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#111110]/80 via-transparent to-transparent" />
              <div className="absolute bottom-4 left-6 right-6 flex items-center justify-between text-xs text-[#F5F2EC]/80">
                <span className="font-serif italic">Chassis Dynamics & Telemetry Verification</span>
                <span className="tracking-widest uppercase text-[10px] text-[#C6A56B]">Silverstone, UK</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5">
            <span className="text-[10px] tracking-[0.25em] uppercase text-[#C6A56B] font-semibold">
              CHAPTER II · UNCOMPROMISED PERFORMANCE
            </span>
            <h3 className="font-serif text-2xl sm:text-3xl text-[#F5F2EC] mt-2 mb-6 font-normal">
              Validated on Circuit, Refined for the Open Road
            </h3>
            <p className="text-sm sm:text-base text-[#A9A49A] font-light leading-relaxed mb-6">
              True luxury requires absolute confidence. Each Vanta prototype undergoes thousands of miles of dynamic testing across extreme arctic climates, high-speed alpine switchbacks, and world-class racing circuits.
            </p>
            <p className="text-sm text-[#A9A49A] font-light leading-relaxed">
              The result is a driving experience of unparalleled duality: civil and whisper-quiet in metropolitan traffic, yet instantaneous and electrifying the moment the throttle is commanded.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
