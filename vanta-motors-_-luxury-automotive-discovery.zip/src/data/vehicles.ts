export interface VehicleColorOption {
  name: string;
  hex: string;
  finish: 'Metallic' | 'Satin' | 'Gloss' | 'Bespoke';
}

export interface Vehicle {
  id: string;
  name: string;
  tagline: string;
  category: string;
  description: string;
  startingPrice: string;
  acceleration: string; // 0-60 mph
  topSpeed: string;
  horsepower: string;
  powertrain: string;
  transmission: string;
  weight: string;
  rangeOrEconomy: string;
  imageUrl: string;
  gallery: string[];
  colors: VehicleColorOption[];
  features: string[];
  dimensions: {
    length: string;
    width: string;
    height: string;
  };
  featured: boolean;
}

export interface GalleryItem {
  id: string;
  title: string;
  subtitle: string;
  category: string;
  imageUrl: string;
  aspect: 'portrait' | 'landscape' | 'wide' | 'tall';
}

export interface Testimonial {
  id: string;
  clientName: string;
  clientRole: string;
  location: string;
  modelCommissioned: string;
  quote: string;
  rating: number;
  avatarUrl: string;
}

// Fallback high-res dark luxury vehicles
export const VEHICLES: Vehicle[] = [
  {
    id: 'spectre-gt',
    name: 'Vanta Spectre GT',
    tagline: 'Pure aerodynamic dominance in bespoke carbon weave.',
    category: 'Hyper-Grand Tourer',
    description: 'A relentless synthesis of twin-turbocharged hybrid performance and bespoke British-Italian tailoring. Engineered with active aerodynamics and sculpted dihedral doors.',
    startingPrice: '$345,000',
    acceleration: '2.6s',
    topSpeed: '218 mph',
    horsepower: '860 HP',
    powertrain: '4.0L Twin-Turbo V8 Hybrid',
    transmission: '8-Speed Dual-Clutch with E-Reverse',
    weight: '3,480 lbs',
    rangeOrEconomy: '24 mpg combined (E-Assist)',
    imageUrl: 'https://images.unsplash.com/photo-1617814076367-b759c7d7e738?auto=format&fit=crop&w=1600&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1617814076367-b759c7d7e738?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?auto=format&fit=crop&w=1200&q=80'
    ],
    colors: [
      { name: 'Obsidian Nocturne', hex: '#111215', finish: 'Metallic' },
      { name: 'Champagne Bronze', hex: '#A38456', finish: 'Satin' },
      { name: 'Liquid Sterling', hex: '#9CA3AF', finish: 'Metallic' },
      { name: 'Bespoke Imperial Burgundy', hex: '#3B1720', finish: 'Gloss' }
    ],
    features: [
      'Carbon-fiber monocoque passenger cell with integrated roll cage',
      'Active front diffusers and speed-activated hydraulic rear airbrake',
      'Hand-stitched semi-aniline leather cockpit with titanium rotary dials',
      'Variable torque-vectoring all-wheel drive with drift telemetry'
    ],
    dimensions: {
      length: '4,685 mm',
      width: '2,045 mm',
      height: '1,195 mm'
    },
    featured: true
  },
  {
    id: 'sovereign-aeromax',
    name: 'Vanta Sovereign Aeromax',
    tagline: 'Whisper-quiet electric propulsion draped in monumental grace.',
    category: 'Ultra-Luxury Flagship Saloon',
    description: 'Designed for captains of industry who demand both commanding presence and absolute serenity. Features quad-motor whisper drive and an acoustic isolation cocoon.',
    startingPrice: '$285,000',
    acceleration: '2.9s',
    topSpeed: '195 mph',
    horsepower: '920 HP',
    powertrain: 'Quad-Motor Permanent Magnet Electric (122 kWh)',
    transmission: 'Dual 2-Speed Direct Planetary Transmission',
    weight: '4,650 lbs',
    rangeOrEconomy: '430 miles (WLTP)',
    imageUrl: 'https://images.unsplash.com/photo-1563720223185-11003d516935?auto=format&fit=crop&w=1600&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1563720223185-11003d516935?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1502877338535-766e1452684a?auto=format&fit=crop&w=1200&q=80'
    ],
    colors: [
      { name: 'Onyx Black Piano', hex: '#0B0C0E', finish: 'Gloss' },
      { name: 'Cashmere Champagne', hex: '#C6A56B', finish: 'Satin' },
      { name: 'Baltic Slate Blue', hex: '#263442', finish: 'Metallic' },
      { name: 'Chalk White Mineral', hex: '#DCDAD3', finish: 'Gloss' }
    ],
    features: [
      'First-class executive rear reclining lounge with calf rests and champagne cooler',
      'Acoustic triple-laminated privacy glass with electrochromic tint dimming',
      'Autonomous high-speed chauffeur assist with lidar suite',
      '40-speaker 2,200W bespoke spatial acoustic sound architecture'
    ],
    dimensions: {
      length: '5,280 mm',
      width: '1,990 mm',
      height: '1,440 mm'
    },
    featured: true
  },
  {
    id: 'valkyrie-gt',
    name: 'Vanta Valkyrie Grand Tourer',
    tagline: 'Naturally aspirated V12 purity meets modern computational poise.',
    category: 'V12 Touring Coupe',
    description: 'A tribute to the timeless proportions of the grand touring golden era, elevated with Formula-derived computational lightweighting and a spine-tingling 9,000 RPM redline.',
    startingPrice: '$410,000',
    acceleration: '3.1s',
    topSpeed: '211 mph',
    horsepower: '790 HP',
    powertrain: '6.5L Naturally Aspirated 65° V12 Hybrid',
    transmission: '7-Speed Sequential Dual-Plate Paddle Shift',
    weight: '3,620 lbs',
    rangeOrEconomy: '19 mpg highway',
    imageUrl: 'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?auto=format&fit=crop&w=1600&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1541348263662-e0c8666574ec?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1508974239320-0a029497e820?auto=format&fit=crop&w=1200&q=80'
    ],
    colors: [
      { name: 'Monaco Silver Grigio', hex: '#717882', finish: 'Metallic' },
      { name: 'Vanta Nero Carbon', hex: '#141414', finish: 'Satin' },
      { name: 'Cognac Tuscan Gold', hex: '#B88E4F', finish: 'Metallic' },
      { name: 'Verde British Forest', hex: '#1C3127', finish: 'Gloss' }
    ],
    features: [
      'Titanium Inconel quad exhaust manifold tuned for orchestral acoustic resonance',
      'Carbon-ceramic Brembo matrix braking system with 10-piston front calipers',
      'Bridge of Weir heirloom leather with precision laser-perforated cooling',
      'Bespoke 3-piece bespoke luggage set matched to chassis upholstery'
    ],
    dimensions: {
      length: '4,810 mm',
      width: '1,980 mm',
      height: '1,280 mm'
    },
    featured: true
  },
  {
    id: 'valo-spider',
    name: 'Vanta Valo Spider',
    tagline: 'Infinite horizon performance in an open-air carbon sculpture.',
    category: 'Open-Air Super Roadster',
    description: 'Sculpted to capture the rush of raw atmospheric power, the Valo Spider features an ultra-light carbon-composite targa roof and dual streamliner buttresses.',
    startingPrice: '$370,000',
    acceleration: '2.7s',
    topSpeed: '214 mph',
    horsepower: '810 HP',
    powertrain: '4.0L Twin-Turbo Flat-Plane V8',
    transmission: '8-Speed Dual-Clutch',
    weight: '3,390 lbs',
    rangeOrEconomy: '22 mpg combined',
    imageUrl: 'https://images.unsplash.com/photo-1544829099-b9a0c07fad1a?auto=format&fit=crop&w=1600&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1544829099-b9a0c07fad1a?auto=format&fit=crop&w=1200&q=80'
    ],
    colors: [
      { name: 'Liquid Bronze', hex: '#9C7B4F', finish: 'Metallic' },
      { name: 'Deep Midnight Shadow', hex: '#0C0D10', finish: 'Satin' },
      { name: 'Nordic Silver Pearl', hex: '#CBCED4', finish: 'Metallic' }
    ],
    features: [
      'Dual rear aerodynamic streamliner buttresses with glass engine showcase',
      'Quick-deploy electro-hydraulic carbon roof with 12-second cycle time',
      'Wind-tunnel sculpted cockpit deflection vane ensuring tranquil high-speed conversation'
    ],
    dimensions: {
      length: '4,640 mm',
      width: '2,020 mm',
      height: '1,180 mm'
    },
    featured: false
  },
  {
    id: 'apex-crosstourer',
    name: 'Vanta Apex CrossTourer',
    tagline: 'Limitless luxury across any terrain, mountain or boulevard.',
    category: 'High-Performance All-Terrain GT',
    description: 'Redefining the grand tourer boundary. Equipped with dual-chamber active air suspension and dynamic off-camber stabilization, the Apex conquers Alpine passes with boardroom comfort.',
    startingPrice: '$315,000',
    acceleration: '3.3s',
    topSpeed: '190 mph',
    horsepower: '760 HP',
    powertrain: 'Twin-Turbocharged 4.4L V8 E-Hybrid',
    transmission: '9-Speed Sport Automatic with Locking Differential',
    weight: '4,450 lbs',
    rangeOrEconomy: '23 mpg combined',
    imageUrl: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1600&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80'
    ],
    colors: [
      { name: 'Alpine Matte Granite', hex: '#3E424B', finish: 'Satin' },
      { name: 'Golden Sand Metallic', hex: '#C6A56B', finish: 'Metallic' },
      { name: 'Stygian Black', hex: '#0D0E10', finish: 'Gloss' }
    ],
    features: [
      'Triple-height active air suspension with 110mm dynamic lift capability',
      'All-terrain terrain response system with real-time vector torque mapping',
      'Hand-finished water-resistant saddle leather with carbon skid protection'
    ],
    dimensions: {
      length: '4,960 mm',
      width: '2,030 mm',
      height: '1,590 mm'
    },
    featured: false
  }
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'gal-1',
    title: 'Matrix Laser Silhouette',
    subtitle: 'Front Fascia Aerodynamic Sculpting',
    category: 'Exterior Architecture',
    imageUrl: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80',
    aspect: 'wide'
  },
  {
    id: 'gal-2',
    title: 'Heirloom Leather Tailoring',
    subtitle: 'Hand-stitched Tuscan Connolly hide with champagne double thread',
    category: 'Atelier Craftsmanship',
    imageUrl: 'https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?auto=format&fit=crop&w=1200&q=80',
    aspect: 'tall'
  },
  {
    id: 'gal-3',
    title: 'Driver-Centric Cockpit',
    subtitle: 'Billet aluminum tactile switches and dual digital flight displays',
    category: 'Interior Ergonomics',
    imageUrl: 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=1200&q=80',
    aspect: 'landscape'
  },
  {
    id: 'gal-4',
    title: 'Directional Forged Alloys',
    subtitle: '22-inch aerospace monoblock wheel with carbon brake ducts',
    category: 'Chassis Engineering',
    imageUrl: 'https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=1200&q=80',
    aspect: 'tall'
  },
  {
    id: 'gal-5',
    title: 'Speed-Tail Air Dynamics',
    subtitle: 'Active aerodynamic wing and carbon rear vortex diffusers',
    category: 'Aerodynamics',
    imageUrl: 'https://images.unsplash.com/photo-1544829099-b9a0c07fad1a?auto=format&fit=crop&w=1200&q=80',
    aspect: 'landscape'
  },
  {
    id: 'gal-6',
    title: 'Sunset Coastal Departure',
    subtitle: 'Grand Touring across the winding Mediterranean cliffs',
    category: 'Lifestyle',
    imageUrl: 'https://images.unsplash.com/photo-1502877338535-766e1452684a?auto=format&fit=crop&w=1200&q=80',
    aspect: 'wide'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 'test-1',
    clientName: 'Julian Vance-Moreau',
    clientRole: 'Private Collector & Architectural Director',
    location: 'Geneva, Switzerland',
    modelCommissioned: 'Vanta Spectre GT Bespoke Edition',
    quote: 'The craftsmanship of the Spectre GT surpasses even my rarest vintage coachbuilds. The transition between effortless electric cruising and the full orchestral roar of the twin-turbo V8 is nothing short of sublime.',
    rating: 5,
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=240&h=240&q=80'
  },
  {
    id: 'test-2',
    clientName: 'Elena Rostova',
    clientRole: 'Technology Founder & Aviation Enthusiast',
    location: 'Monaco',
    modelCommissioned: 'Vanta Sovereign Aeromax',
    quote: 'Every detail in the Sovereign cabin feels intentional. The acoustic isolation cocoon allows me to conduct international board reviews at 130 mph in absolute library tranquility. A true masterclass.',
    rating: 5,
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=240&h=240&q=80'
  },
  {
    id: 'test-3',
    clientName: 'Marcus Sterling',
    clientRole: 'Automotive Historian & Concours Judge',
    location: 'Mayfair, London',
    modelCommissioned: 'Vanta Valkyrie Grand Tourer',
    quote: 'In an era of homogenized design, Vanta Motors stands alone. The naturally aspirated V12 responds with instantaneous mechanical emotion that digital hypercars simply cannot replicate.',
    rating: 5,
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=240&h=240&q=80'
  }
];

export const BRAND_HIGHLIGHTS = [
  {
    title: 'Curated Luxury Collection',
    description: 'Hand-selected and bespoke coachbuilt vehicles crafted to uncompromising standards of aesthetic refinement.',
    icon: 'Sparkles'
  },
  {
    title: 'Exceptional Craftsmanship',
    description: 'Precision-milled aerospace alloys, hand-planed open pore veneers, and heirloom Connolly hides.',
    icon: 'ShieldCheck'
  },
  {
    title: 'Personalized Experience',
    description: 'One-on-one atelier design consultations, private circuit test drives, and white-glove global transport.',
    icon: 'Compass'
  },
  {
    title: 'Trusted Automotive Experts',
    description: 'Master mechanics, bespoke automotive designers, and dedicated private client liaisons.',
    icon: 'Award'
  }
];
